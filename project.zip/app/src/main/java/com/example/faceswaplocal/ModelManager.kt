package com.example.faceswaplocal

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** 管理三个模型文件：采用移动端高速组合 (det_500m + w600k_mbf + inswapper_128_fp16)，并兼容旧模型导入。 */
object ModelManager {
    const val DET = "det_500m.onnx"
    const val REC = "w600k_mbf.onnx"
    const val SWAP = "inswapper_128_fp16.onnx"

    private const val MIN_BYTES = 500_000L

    fun dir(ctx: Context): File = File(ctx.filesDir, "models").also { it.mkdirs() }

    fun file(ctx: Context, name: String): File = File(dir(ctx), name)

    fun has(ctx: Context, name: String): Boolean = file(ctx, name).length() > MIN_BYTES

    fun ready(ctx: Context): Boolean = listOf(DET, REC, SWAP).all { has(ctx, it) }

    fun clearAll(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
    }

    fun urlFor(base: String, name: String): String {
        val b = base.trim().trimEnd('/')
        return when (name) {
            DET -> "$b/deepghs/insightface/resolve/main/buffalo_s/det_500m.onnx"
            REC -> "$b/deepghs/insightface/resolve/main/buffalo_s/w600k_mbf.onnx"
            else -> "$b/ApacheOne/insightface/resolve/main/insightface/inswapper_128_fp16.onnx"
        }
    }

    /** 带断点续传的下载。 */
    fun download(url: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val part = File(dest.path + ".part")
        var existing = if (part.exists()) part.length() else 0L
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0")
            if (existing > 0) setRequestProperty("Range", "bytes=$existing-")
        }
        try {
            val code = conn.responseCode
            if (code == 416 && existing > 0) {
                finish(part, dest)
                return
            }
            if (code != 200 && code != 206) throw IOException("服务器返回 HTTP $code")
            val append = code == 206
            if (!append) existing = 0
            val len = conn.contentLengthLong
            val total = if (len > 0) existing + len else -1L
            var done = existing
            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { out ->
                    val buf = ByteArray(256 * 1024)
                    var lastReport = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - lastReport > 300) {
                            lastReport = now
                            onProgress(done, total)
                        }
                    }
                }
            }
            onProgress(done, total)
            finish(part, dest)
        } finally {
            conn.disconnect()
        }
    }

    private fun finish(part: File, dest: File) {
        if (dest.exists()) dest.delete()
        if (!part.renameTo(dest)) throw IOException("无法保存文件")
    }

    /** 支持导入任意版本的 det / w600k / inswapper / hyperswap 模型文件或 zip 包。 */
    fun importUris(ctx: Context, uris: List<Uri>): List<String> {
        val cr = ctx.contentResolver
        val msgs = ArrayList<String>()
        for (uri in uris) {
            val name = displayName(cr, uri)
            val lower = name.lowercase()
            try {
                when {
                    lower.endsWith(".zip") -> {
                        val got = cr.openInputStream(uri)!!.use { extractZip(ctx, it) }
                        msgs.add(if (got.isEmpty()) "$name：压缩包里没有找到需要的文件" else "$name：已解出 ${got.joinToString("、")}")
                    }
                    lower.contains("det_") -> {
                        copyTo(cr, uri, file(ctx, DET)); msgs.add("$name：已导入为人脸检测模型")
                    }
                    lower.contains("w600k") -> {
                        copyTo(cr, uri, file(ctx, REC)); msgs.add("$name：已导入为人脸识别模型")
                    }
                    lower.contains("inswapper") || lower.contains("hyperswap") -> {
                        copyTo(cr, uri, file(ctx, SWAP)); msgs.add("$name：已导入为换脸模型")
                    }
                    else -> msgs.add("$name：不认识这个文件，已跳过")
                }
            } catch (e: Exception) {
                msgs.add("$name：导入失败（${e.message}）")
            }
        }
        return msgs
    }

    private fun extractZip(ctx: Context, input: InputStream): List<String> {
        val got = ArrayList<String>()
        ZipInputStream(input).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val base = e.name.substringAfterLast('/').lowercase()
                val target = when {
                    base.startsWith("det_") && base.endsWith(".onnx") -> file(ctx, DET)
                    base.startsWith("w600k") && base.endsWith(".onnx") -> file(ctx, REC)
                    (base.contains("inswapper") || base.contains("hyperswap")) && base.endsWith(".onnx") -> file(ctx, SWAP)
                    else -> null
                }
                if (target != null && !e.isDirectory) {
                    FileOutputStream(target).use { out -> zin.copyTo(out) }
                    got.add(e.name.substringAfterLast('/'))
                }
            }
        }
        return got
    }

    private fun copyTo(cr: ContentResolver, uri: Uri, dest: File) {
        val tmp = File(dest.path + ".tmp")
        cr.openInputStream(uri)!!.use { input ->
            FileOutputStream(tmp).use { out -> input.copyTo(out, 256 * 1024) }
        }
        if (dest.exists()) dest.delete()
        if (!tmp.renameTo(dest)) throw IOException("无法保存文件")
    }

    fun displayName(cr: ContentResolver, uri: Uri): String {
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) return c.getString(i) ?: "未命名"
            }
        }
        return uri.lastPathSegment ?: "未命名"
    }
}
