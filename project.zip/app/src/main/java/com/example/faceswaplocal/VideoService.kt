package com.example.faceswaplocal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import java.io.File

/** Activity 和后台服务之间共享的任务状态。 */
object VideoJob {
    @Volatile var running = false
    @Volatile var percent = 0
    @Volatile var message = ""
    @Volatile var processor: VideoProcessor? = null

    fun reset(msg: String) {
        running = true
        percent = 0
        message = msg
        processor = null
    }
}

/**
 * 前台服务：视频处理要很久，放在这里跑，切到别的 app 或锁屏也不会被系统停掉。
 */
class VideoService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "视频处理", NotificationManager.IMPORTANCE_LOW),
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 用 startForegroundService 启动后必须尽快调用 startForeground
        startForeground(
            NOTI_ID,
            notification("正在准备…", 0, true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
        )

        val video = intent?.getStringExtra("video")?.let { Uri.parse(it) }
        val source = intent?.getStringExtra("source")?.let { Uri.parse(it) }
        if (video == null || source == null) {
            VideoJob.running = false
            VideoJob.message = "没有收到视频或来源照片。"
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val opts = SwapOptions(
            strength = intent?.getFloatExtra("strength", 1f) ?: 1f,
            colorMatch = intent?.getFloatExtra("color", 0f) ?: 0f,
            sharpen = intent?.getFloatExtra("sharpen", 0f) ?: 0f,
        )
        val maxFps = intent?.getIntExtra("maxFps", 15) ?: 15

        Thread { work(video, source, opts, maxFps) }.start()
        return START_NOT_STICKY
    }

    private fun work(video: Uri, source: Uri, opts: SwapOptions, maxFps: Int) {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "faceswap:video")
        wl.acquire(6 * 60 * 60 * 1000L)
        val outFile = File(cacheDir, "swap_${System.currentTimeMillis()}.mp4")
        var engine: FaceEngine? = null
        var finalText = ""
        try {
            VideoJob.message = "正在加载模型…"
            val eng = try {
                FaceEngine(this)
            } catch (e: Exception) {
                throw UserError("模型加载失败，文件可能不完整，请回到主界面重新下载。（${e.message}）")
            }
            engine = eng

            VideoJob.message = "分析来源照片…"
            val srcBmp = ImageLoader.load(this, source, 2048)
            val sf = eng.detect(srcBmp).maxByOrNull { it.area }
                ?: throw UserError("来源照片里没有检测到人脸，换一张正脸清楚的照片。")
            val emb = eng.embed(srcBmp, sf)

            val proc = VideoProcessor(this, eng)
            VideoJob.processor = proc
            val t0 = System.currentTimeMillis()
            var lastNoti = 0L
            val ok = proc.run(VideoProcessor.Params(video, emb, opts, maxFps, 1280), outFile) { frames, pts, dur ->
                val pct = if (dur > 0) (pts * 100 / dur).toInt().coerceIn(0, 100) else 0
                val elapsed = System.currentTimeMillis() - t0
                val eta = if (pct >= 2) elapsed * (100 - pct) / pct / 60000 else -1L
                val msg = "已处理 $pct%（${frames} 帧）" + if (eta >= 0) "，预计还要约 ${eta + 1} 分钟" else ""
                VideoJob.percent = pct
                VideoJob.message = msg
                val now = System.currentTimeMillis()
                if (now - lastNoti > 3000) {
                    lastNoti = now
                    getSystemService(NotificationManager::class.java)
                        .notify(NOTI_ID, notification(msg, pct, true))
                }
            }
            finalText = if (!ok) {
                "已取消。"
            } else if (saveToGallery(outFile)) {
                "完成，已保存到相册（Movies/FaceSwap）。" +
                    if (proc.audioSkipped) "\n原声的格式不支持，这个视频没有声音。" else ""
            } else {
                "视频处理完了，但保存到相册失败。"
            }
            VideoJob.percent = if (ok) 100 else VideoJob.percent
        } catch (e: UserError) {
            finalText = e.message ?: "出错了"
        } catch (e: OutOfMemoryError) {
            finalText = "内存不够了，请换一个分辨率低一些的视频。"
        } catch (e: Throwable) {
            finalText = "出错：${e.javaClass.simpleName} ${e.message}"
        } finally {
            try { engine?.close() } catch (e: Exception) { }
            outFile.delete()
            if (wl.isHeld) wl.release()
        }
        VideoJob.message = finalText
        VideoJob.processor = null
        VideoJob.running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java)
            .notify(NOTI_ID + 1, notification(finalText, 0, false))
        stopSelf()
    }

    private fun saveToGallery(file: File): Boolean {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "faceswap_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FaceSwap")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            contentResolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun notification(text: String, progress: Int, ongoing: Boolean): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("本地换脸 · 视频")
            .setContentText(text)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
        if (ongoing) b.setProgress(100, progress, false)
        return b.build()
    }

    companion object {
        private const val CHANNEL = "video"
        private const val NOTI_ID = 42
    }
}
