package com.example.faceswaplocal

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.io.File
import java.io.FileInputStream
import kotlin.math.abs

class UserError(msg: String) : Exception(msg)

class MainActivity : Activity() {

    private var srcUri: Uri? = null
    private var tgtUri: Uri? = null
    private var videoUri: Uri? = null
    private var engine: FaceEngine? = null

    private var resultBitmap: Bitmap? = null
    private var resultVideoFile: File? = null

    @Volatile private var busy = false
    @Volatile private var cancelled = false

    private lateinit var modelText: TextView
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var videoProgressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var srcView: ImageView
    private lateinit var tgtView: ImageView
    private lateinit var resultView: ImageView
    private lateinit var allSwitch: Switch
    private lateinit var hdVideoSwitch: Switch
    private lateinit var cancelBtn: Button
    private lateinit var saveBtn: Button

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        fun add(v: View, top: Int = 10) {
            root.addView(
                v,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(top) },
            )
        }

        add(TextView(this).apply {
            text = "本地换脸（图片 + 视频）"
            textSize = 24f
        }, 0)
        add(TextView(this).apply {
            text = "全部在手机本地离线运行，素材不会上传。请仅用于本人或已获得授权的素材。"
            textSize = 13f
        })

        // ---- 1. 模型准备
        add(TextView(this).apply { text = "1. 准备模型"; textSize = 17f }, 20)
        modelText = TextView(this).apply { textSize = 13f }
        add(modelText)
        add(button("下载模型（huggingface.co）") { startDownload("https://huggingface.co") })
        add(button("下载模型（镜像 hf-mirror.com）") { startDownload("https://hf-mirror.com") }, 4)
        add(button("从手机文件导入模型") { pickModels() }, 4)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        add(progressBar)
        progressText = TextView(this).apply { textSize = 12f }
        add(progressText, 2)

        // ---- 2. 选择素材
        add(TextView(this).apply { text = "2. 选择素材"; textSize = 17f }, 20)
        add(button("① 选择来源人脸照片（要换成谁）") { pickImage(REQ_SRC) })
        srcView = thumb()
        add(srcView, 6)

        add(button("② 选择目标照片（图片换脸模式）") { pickImage(REQ_TGT) }, 12)
        add(button("② 选择目标视频（视频换脸模式）") { pickVideo() }, 6)
        tgtView = thumb()
        add(tgtView, 6)

        allSwitch = Switch(this).apply {
            text = "画面有多张脸时全部替换（默认只换最大的一张）"
            textSize = 13f
        }
        add(allSwitch, 12)

        hdVideoSwitch = Switch(this).apply {
            text = "视频高清模式（720P / 24fps，关闭则为 540P / 18fps 更快）"
            textSize = 13f
            isChecked = true
        }
        add(hdVideoSwitch, 6)

        // ---- 3. 开始换脸
        add(TextView(this).apply { text = "3. 执行换脸"; textSize = 17f }, 20)
        add(button("开始换脸（自动识别图片或视频）") { startSwap() })

        cancelBtn = button("取消当前任务") {
            cancelled = true
            say("正在取消，请稍候…")
        }.apply {
            visibility = View.GONE
        }
        add(cancelBtn, 6)

        videoProgressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        add(videoProgressBar, 8)

        statusText = TextView(this).apply { textSize = 13f }
        add(statusText)

        resultView = ImageView(this).apply {
            adjustViewBounds = true
            maxHeight = dp(320)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        add(resultView, 12)

        saveBtn = button("保存到手机相册") { saveResult() }.apply { isEnabled = false }
        add(saveBtn, 12)

        refreshModelStatus()
    }

    override fun onDestroy() {
        cancelled = true
        engine?.close()
        engine = null
        super.onDestroy()
    }

    // ------------------------------------------------------------ 界面小工具

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun thumb(): ImageView = ImageView(this).apply {
        adjustViewBounds = true
        maxHeight = dp(180)
        scaleType = ImageView.ScaleType.FIT_CENTER
    }

    private fun say(msg: String) {
        runOnUiThread { statusText.text = msg }
    }

    private fun refreshModelStatus() {
        val items = listOf(
            ModelManager.DET to "人脸检测",
            ModelManager.REC to "人脸识别",
            ModelManager.SWAP to "换脸",
        )
        modelText.text = items.joinToString("
") { (file, label) ->
            val ok = ModelManager.has(this, file)
            val mb = ModelManager.file(this, file).length() / 1_000_000
            (if (ok) "✓ " else "✗ ") + label + "模型 " + file + (if (ok) "  ${mb} MB" else "  未就绪")
        }
    }

    // ------------------------------------------------------------ 选文件

    private fun pickImage(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(i, req)
    }

    private fun pickVideo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(i, REQ_VIDEO)
    }

    private fun pickModels() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, REQ_MODEL)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_SRC -> data.data?.let {
                srcUri = it
                showImageThumb(srcView, it)
            }
            REQ_TGT -> data.data?.let {
                tgtUri = it
                videoUri = null
                showImageThumb(tgtView, it)
                say("当前模式：图片换脸")
            }
            REQ_VIDEO -> data.data?.let {
                videoUri = it
                tgtUri = null
                showVideoThumb(tgtView, it)
                say("当前模式：视频换脸")
            }
            REQ_MODEL -> {
                val uris = ArrayList<Uri>()
                val cd = data.clipData
                if (cd != null) {
                    for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
                } else {
                    data.data?.let { uris.add(it) }
                }
                importModels(uris)
            }
        }
    }

    private fun showImageThumb(view: ImageView, uri: Uri) {
        Thread {
            try {
                val bmp = ImageLoader.load(this, uri, 1024)
                runOnUiThread { view.setImageBitmap(bmp) }
            } catch (e: Exception) {
                say("读取照片失败：${e.message}")
            }
        }.start()
    }

    private fun showVideoThumb(view: ImageView, uri: Uri) {
        Thread {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, uri)
                val cover = retriever.getFrameAtTime(0)
                val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                runOnUiThread {
                    if (cover != null) view.setImageBitmap(cover)
                    say("已选择目标视频（时长 ${"%.1f".format(durationMs / 1000.0)} 秒）")
                }
            } catch (e: Exception) {
                say("读取视频信息失败：${e.message}")
            } finally {
                try { retriever.release() } catch (_: Exception) {}
            }
        }.start()
    }

    // ------------------------------------------------------------ 模型下载与导入

    private fun startDownload(base: String) {
        if (busy) return
        busy = true
        progressBar.visibility = View.VISIBLE
        Thread {
            try {
                for (name in listOf(ModelManager.DET, ModelManager.REC, ModelManager.SWAP)) {
                    if (ModelManager.has(this, name)) continue
                    say("正在下载 $name …")
                    val url = ModelManager.urlFor(base, name)
                    ModelManager.download(url, ModelManager.file(this, name)) { done, total ->
                        runOnUiThread {
                            if (total > 0) {
                                progressBar.progress = (done * 100 / total).toInt()
                                progressText.text = "$name  ${done / 1_000_000} / ${total / 1_000_000} MB"
                            } else {
                                progressText.text = "$name  ${done / 1_000_000} MB"
                            }
                        }
                    }
                }
                engine?.close()
                engine = null
                say("模型已准备好。")
            } catch (e: Exception) {
                say("下载失败：${e.message}。再点一次会接着下，或者换另一个下载源。")
            } finally {
                runOnUiThread {
                    busy = false
                    progressBar.visibility = View.GONE
                    progressText.text = ""
                    refreshModelStatus()
                }
            }
        }.start()
    }

    private fun importModels(uris: List<Uri>) {
        if (uris.isEmpty() || busy) return
        busy = true
        say("正在导入模型…")
        Thread {
            val msgs = ModelManager.importUris(this, uris)
            engine?.close()
            engine = null
            say(msgs.joinToString("
"))
            runOnUiThread {
                busy = false
                refreshModelStatus()
            }
        }.start()
    }

    // ------------------------------------------------------------ 换脸分发

    private fun startSwap() {
        if (busy) return
        val s = srcUri
        if (s == null) {
            say("请先选择【来源人脸照片】。")
            return
        }
        if (tgtUri == null && videoUri == null) {
            say("请先选择【目标照片】或【目标视频】。")
            return
        }
        if (!ModelManager.ready(this)) {
            say("模型还没准备好，请先下载或导入模型。")
            return
        }

        if (videoUri != null) {
            runVideoSwap(s, videoUri!!)
        } else {
            runImageSwap(s, tgtUri!!)
        }
    }

    // ------------------------------------------------------------ 图片换脸

    private fun runImageSwap(s: Uri, t: Uri) {
        busy = true
        cancelled = false
        saveBtn.isEnabled = false
        resultBitmap = null
        resultVideoFile = null
        resultView.setImageDrawable(null)
        val all = allSwitch.isChecked

        Thread {
            try {
                val t0 = System.currentTimeMillis()
                say("正在加载模型…")
                val eng = getEngine()

                say("读取照片…")
                val srcBmp = ImageLoader.load(this, s, 2048)
                val tgtBmp = ImageLoader.load(this, t, 2560)

                say("检测来源照片里的脸…")
                val sf = eng.detect(srcBmp).maxByOrNull { it.area }
                    ?: throw UserError("来源照片里没有检测到人脸，换一张正脸清楚的照片试试。")
                val emb = eng.embed(srcBmp, sf)
                srcBmp.recycle()

                say("检测目标照片里的脸…")
                val faces = eng.detect(tgtBmp).sortedByDescending { it.area }
                if (faces.isEmpty()) throw UserError("目标照片里没有检测到人脸。")
                val chosen = if (all) faces else faces.take(1)

                val out = tgtBmp.copy(Bitmap.Config.ARGB_8888, true)
                val notes = ArrayList<String>()
                for ((i, f) in chosen.withIndex()) {
                    say("正在换第 ${i + 1} / ${chosen.size} 张脸…")
                    if (abs(f.yaw()) > 0.4f || abs(f.pitch() - 0.5f) > 0.2f) {
                        notes.add("第 ${i + 1} 张脸转头或低头角度偏大，效果可能不好。")
                    }
                    eng.swap(tgtBmp, out, f, emb)
                }
                tgtBmp.recycle()

                resultBitmap = out
                val sec = (System.currentTimeMillis() - t0) / 1000.0
                runOnUiThread {
                    resultView.setImageBitmap(out)
                    saveBtn.text = "保存换脸照片到相册"
                    saveBtn.isEnabled = true
                }
                say("图片换脸完成，用时 ${"%.1f".format(sec)} 秒。" + if (notes.isNotEmpty()) "
${notes.joinToString("
")}" else "")
            } catch (e: UserError) {
                say(e.message ?: "出错了")
            } catch (e: OutOfMemoryError) {
                say("内存不够了，请换一张小一点的照片。")
            } catch (e: Throwable) {
                say("出错：${e.javaClass.simpleName} ${e.message}")
            } finally {
                runOnUiThread { busy = false }
            }
        }.start()
    }

    // ------------------------------------------------------------ 视频换脸（生成完整 MP4 + 音频）

    private fun runVideoSwap(s: Uri, v: Uri) {
        busy = true
        cancelled = false
        saveBtn.isEnabled = false
        resultBitmap = null
        resultVideoFile = null
        resultView.setImageDrawable(null)
        videoProgressBar.progress = 0
        videoProgressBar.visibility = View.VISIBLE
        cancelBtn.visibility = View.VISIBLE

        val all = allSwitch.isChecked
        val isHd = hdVideoSwitch.isChecked
        val fps = if (isHd) 24 else 18
        val maxDim = if (isHd) 720 else 540

        Thread {
            try {
                val t0 = System.currentTimeMillis()
                say("正在加载模型…")
                val eng = getEngine()

                say("正在提取来源人脸特征…")
                val srcBmp = ImageLoader.load(this, s, 2048)
                val sf = eng.detect(srcBmp).maxByOrNull { it.area }
                    ?: throw UserError("来源照片里没有检测到人脸，换一张正脸清楚的照片试试。")
                val emb = eng.embed(srcBmp, sf)
                srcBmp.recycle()

                val outFile = File(cacheDir, "swapped_video_${System.currentTimeMillis()}.mp4")
                var lastPreview: Bitmap? = null

                VideoProcessor.processVideo(
                    ctx = this,
                    engine = eng,
                    srcFaceEmb = emb,
                    videoUri = v,
                    outputFile = outFile,
                    swapAllFaces = all,
                    targetFps = fps,
                    maxDimension = maxDim,
                    isCancelled = { cancelled },
                    onProgress = { cur, total, preview ->
                        val pct = (cur * 100 / total).coerceIn(0, 100)
                        runOnUiThread {
                            videoProgressBar.progress = pct
                            statusText.text = "正在合成视频：$cur / $total 帧 ($pct%)…"
                            if (preview != null) {
                                lastPreview?.recycle()
                                lastPreview = preview
                                resultView.setImageBitmap(preview)
                            }
                        }
                    }
                )

                resultVideoFile = outFile
                val sec = (System.currentTimeMillis() - t0) / 1000.0
                runOnUiThread {
                    saveBtn.text = "保存换脸视频（MP4）到相册"
                    saveBtn.isEnabled = true
                }
                say("视频换脸合成完成！总用时 ${"%.1f".format(sec)} 秒，点击下方按钮保存到相册即可播放。")
            } catch (e: UserError) {
                say(e.message ?: "已停止")
            } catch (e: OutOfMemoryError) {
                say("视频处理内存不足，请关闭高清模式后重试。")
            } catch (e: Throwable) {
                say("视频处理出错：${e.javaClass.simpleName} ${e.message}")
            } finally {
                runOnUiThread {
                    busy = false
                    videoProgressBar.visibility = View.GONE
                    cancelBtn.visibility = View.GONE
                }
            }
        }.start()
    }

    private fun getEngine(): FaceEngine {
        val eng = engine ?: try {
            FaceEngine(this)
        } catch (e: Exception) {
            throw UserError("模型加载失败，文件可能不完整，请删除后重新下载。（${e.message}）")
        }
        engine = eng
        return eng
    }

    // ------------------------------------------------------------ 保存图片或视频到相册

    private fun saveResult() {
        val vid = resultVideoFile
        if (vid != null && vid.exists()) {
            saveVideoToGallery(vid)
            return
        }
        val bmp = resultBitmap ?: return
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "faceswap_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceSwap")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                say("保存失败。")
                return
            }
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            say("照片已保存到相册（Pictures/FaceSwap）。")
        } catch (e: Exception) {
            say("保存失败：${e.message}")
        }
    }

    private fun saveVideoToGallery(videoFile: File) {
        Thread {
            try {
                say("正在导出视频到系统相册…")
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "faceswap_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FaceSwap")
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri == null) {
                    say("保存视频失败。")
                    return@Thread
                }
                contentResolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(videoFile).use { input ->
                        input.copyTo(out, 256 * 1024)
                    }
                }
                say("视频已保存到系统相册（Movies/FaceSwap），可直接打开相册观看！")
            } catch (e: Exception) {
                say("保存视频失败：${e.message}")
            }
        }.start()
    }

    companion object {
        private const val REQ_SRC = 1
        private const val REQ_TGT = 2
        private const val REQ_MODEL = 3
        private const val REQ_VIDEO = 4
    }
}
