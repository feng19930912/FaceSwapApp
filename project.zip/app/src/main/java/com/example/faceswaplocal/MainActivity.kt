package com.example.faceswaplocal

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.RadioButton
import android.widget.RadioGroup
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.abs

class UserError(msg: String) : Exception(msg)

/** strength：换脸强度 0~1；colorMatch：肤色向原图靠拢 0~1；sharpen：细节增强，0 为关闭。 */
class SwapOptions(
    val strength: Float = 1f,
    val colorMatch: Float = 0f,
    val sharpen: Float = 0f,
)

class MainActivity : Activity() {

    private var srcUri: Uri? = null
    private var tgtUri: Uri? = null
    private var engine: FaceEngine? = null
    private var result: Bitmap? = null
    private var busy = false

    private lateinit var modelText: TextView
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var srcView: ImageView
    private lateinit var tgtView: ImageView
    private lateinit var resultView: ImageView
    private lateinit var allSwitch: Switch
    private lateinit var saveBtn: Button
    private lateinit var strengthBar: SeekBar
    private lateinit var colorBar: SeekBar
    private lateinit var sharpenBar: SeekBar

    private var videoUri: Uri? = null
    private lateinit var videoInfo: TextView
    private lateinit var fpsGroup: RadioGroup
    private lateinit var videoStatus: TextView
    private lateinit var videoBar: ProgressBar
    private lateinit var videoStartBtn: Button
    private lateinit var videoCancelBtn: Button
    private val fpsValues = intArrayOf(15, 10, 120)
    private val handler = Handler(Looper.getMainLooper())
    private var polling = false
    private val pollTask = object : Runnable {
        override fun run() {
            val running = VideoJob.running
            videoStatus.text = VideoJob.message
            videoBar.progress = VideoJob.percent
            videoBar.visibility = if (running) View.VISIBLE else View.GONE
            videoStartBtn.isEnabled = !running
            videoCancelBtn.isEnabled = running
            if (running) handler.postDelayed(this, 700) else polling = false
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        fun add(v: View, top: Int = 10) {
            root.addView(
                v,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(top) },
            )
        }

        add(TextView(this).apply {
            text = "本地换脸"
            textSize = 24f
        }, 0)
        add(TextView(this).apply {
            text = "全部在手机上运行，照片不会上传。请只使用本人或已经同意的人的照片。"
            textSize = 13f
        })

        // ---- 模型
        add(TextView(this).apply { text = "1. 准备模型"; textSize = 17f }, 20)
        modelText = TextView(this).apply { textSize = 13f }
        add(modelText)
        add(button("下载模型（huggingface.co）") { startDownload("https://huggingface.co") })
        add(button("下载模型（镜像 hf-mirror.com）") { startDownload("https://hf-mirror.com") }, 4)
        add(button("从手机文件导入模型") { pickModels() }, 4)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        add(progressBar)
        progressText = TextView(this).apply { textSize = 12f }
        add(progressText, 2)

        // ---- 照片
        add(TextView(this).apply { text = "2. 选照片"; textSize = 17f }, 20)
        add(button("选择脸的来源照片（要换成谁）") { pickImage(REQ_SRC) })
        srcView = thumb()
        add(srcView, 6)
        add(button("选择目标照片（要换掉谁的脸）") { pickImage(REQ_TGT) }, 12)
        tgtView = thumb()
        add(tgtView, 6)
        allSwitch = Switch(this).apply {
            text = "目标照片有多张脸时全部替换（默认只换最大的一张）"
            textSize = 13f
        }
        add(allSwitch, 12)

        // ---- 效果调节
        fun slider(label: String, initial: Int): SeekBar {
            val tv = TextView(this).apply {
                textSize = 13f
                text = "$label：$initial"
            }
            val sb = SeekBar(this).apply {
                max = 100
                progress = initial
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                        tv.text = "$label：$p"
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            add(tv, 12)
            add(sb, 0)
            return sb
        }
        add(TextView(this).apply { text = "效果调节（每次改完要重新点开始换脸）"; textSize = 15f }, 20)
        strengthBar = slider("换脸强度（100 为完全换脸，调低会透出原来的脸）", 100)
        colorBar = slider("肤色贴近原图（0 为不调整）", 45)
        sharpenBar = slider("细节增强（0 为关闭）", 50)

        // ---- 开始
        add(TextView(this).apply { text = "3. 换脸"; textSize = 17f }, 20)
        add(button("开始换脸") { runSwap() })
        statusText = TextView(this).apply { textSize = 13f }
        add(statusText)
        resultView = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        add(resultView, 12)
        saveBtn = button("保存到相册") { save() }.apply { isEnabled = false }
        add(saveBtn, 12)

        // ---- 视频
        add(TextView(this).apply { text = "4. 视频换脸"; textSize = 17f }, 28)
        add(TextView(this).apply {
            text = "用上面选好的来源照片和效果滑块。只换画面里最大的那张脸，原声会保留。" +
                "处理很慢，建议先用 3 到 5 秒的片段试效果。处理时请不要关掉 app，可以切到别的应用。"
            textSize = 13f
        })
        add(button("选择目标视频") { pickVideo() })
        videoInfo = TextView(this).apply { textSize = 13f }
        add(videoInfo, 6)
        add(TextView(this).apply { text = "输出帧率（越低越快，但画面不够流畅）"; textSize = 13f }, 12)
        fpsGroup = RadioGroup(this).apply { orientation = LinearLayout.VERTICAL }
        val fpsLabels = listOf("最多 15 帧/秒（推荐）", "最多 10 帧/秒（更快）", "保持原帧率（最慢）")
        for ((i, label) in fpsLabels.withIndex()) {
            val rb = RadioButton(this).apply {
                text = label
                id = 100 + i
            }
            fpsGroup.addView(rb)
        }
        fpsGroup.check(100)
        add(fpsGroup, 4)
        videoStartBtn = button("开始处理视频") { startVideo() }
        add(videoStartBtn, 12)
        videoCancelBtn = button("取消处理") { VideoJob.processor?.cancelled = true }.apply { isEnabled = false }
        add(videoCancelBtn, 4)
        videoBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        add(videoBar)
        videoStatus = TextView(this).apply { textSize = 13f }
        add(videoStatus, 4)

        refreshModelStatus()
        if (VideoJob.running) startPolling()
    }

    override fun onDestroy() {
        engine?.close()
        engine = null
        super.onDestroy()
    }

    // ------------------------------------------------------------ 界面小工具

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun thumb(): ImageView = ImageView(this).apply {
        adjustViewBounds = true
        maxHeight = dp(200)
        scaleType = ImageView.ScaleType.FIT_CENTER
    }

    private fun say(msg: String) {
        runOnUiThread { statusText.text = msg }
    }

    private fun refreshModelStatus() {
        val items = listOf(
            ModelManager.DET to "人脸检测",
            ModelManager.REC to "人脸识别",
            ModelManager.SWAP to "换脸",
        )
        modelText.text = items.joinToString("\n") { (file, label) ->
            val ok = ModelManager.has(this, file)
            val mb = ModelManager.file(this, file).length() / 1_000_000
            (if (ok) "✓ " else "✗ ") + label + "模型 " + file + (if (ok) "  ${mb} MB" else "  未就绪")
        }
    }

    // ------------------------------------------------------------ 选文件

    private fun pickImage(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(i, req)
    }

    private fun pickModels() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, REQ_MODEL)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_SRC -> data.data?.let { srcUri = it; showThumb(srcView, it) }
            REQ_TGT -> data.data?.let { tgtUri = it; showThumb(tgtView, it) }
            REQ_VIDEO -> data.data?.let { videoUri = it; describeVideo(it) }
            REQ_MODEL -> {
                val uris = ArrayList<Uri>()
                val cd = data.clipData
                if (cd != null) {
                    for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
                } else {
                    data.data?.let { uris.add(it) }
                }
                importModels(uris)
            }
        }
    }

    private fun showThumb(view: ImageView, uri: Uri) {
        Thread {
            try {
                val bmp = ImageLoader.load(this, uri, 1024)
                runOnUiThread { view.setImageBitmap(bmp) }
            } catch (e: Exception) {
                say("读取照片失败：${e.message}")
            }
        }.start()
    }

    // ------------------------------------------------------------ 模型下载与导入

    private fun startDownload(base: String) {
        if (busy) return
        busy = true
        progressBar.visibility = View.VISIBLE
        Thread {
            try {
                for (name in listOf(ModelManager.DET, ModelManager.REC, ModelManager.SWAP)) {
                    if (ModelManager.has(this, name)) continue
                    say("正在下载 $name …")
                    val url = ModelManager.urlFor(base, name)
                    ModelManager.download(url, ModelManager.file(this, name)) { done, total ->
                        runOnUiThread {
                            if (total > 0) {
                                progressBar.progress = (done * 100 / total).toInt()
                                progressText.text = "$name  ${done / 1_000_000} / ${total / 1_000_000} MB"
                            } else {
                                progressText.text = "$name  ${done / 1_000_000} MB"
                            }
                        }
                    }
                }
                engine?.close()
                engine = null
                say("模型已准备好。")
            } catch (e: Exception) {
                say("下载失败：${e.message}。再点一次会接着下，或者换另一个下载源。")
            } finally {
                runOnUiThread {
                    busy = false
                    progressBar.visibility = View.GONE
                    progressText.text = ""
                    refreshModelStatus()
                }
            }
        }.start()
    }

    private fun importModels(uris: List<Uri>) {
        if (uris.isEmpty() || busy) return
        busy = true
        say("正在导入模型…")
        Thread {
            val msgs = ModelManager.importUris(this, uris)
            engine?.close()
            engine = null
            say(msgs.joinToString("\n"))
            runOnUiThread {
                busy = false
                refreshModelStatus()
            }
        }.start()
    }

    // ------------------------------------------------------------ 换脸

    private fun runSwap() {
        if (busy) return
        if (VideoJob.running) {
            say("视频正在处理，请等它完成后再换照片。")
            return
        }
        val s = srcUri
        val t = tgtUri
        if (s == null || t == null) {
            say("请先选好来源照片和目标照片。")
            return
        }
        if (!ModelManager.ready(this)) {
            say("模型还没准备好，请先下载或导入模型。")
            return
        }
        busy = true
        saveBtn.isEnabled = false
        resultView.setImageDrawable(null)
        val all = allSwitch.isChecked
        val opts = SwapOptions(
            strength = strengthBar.progress / 100f,
            colorMatch = colorBar.progress / 100f,
            sharpen = sharpenBar.progress / 100f * 1.5f,
        )
        Thread {
            try {
                val t0 = System.currentTimeMillis()
                val (bmp, notes) = process(s, t, all, opts)
                result = bmp
                val sec = (System.currentTimeMillis() - t0) / 1000.0
                runOnUiThread {
                    resultView.setImageBitmap(bmp)
                    saveBtn.isEnabled = true
                }
                say("完成，用时 ${"%.1f".format(sec)} 秒。" + if (notes.isNotEmpty()) "\n$notes" else "")
            } catch (e: UserError) {
                say(e.message ?: "出错了")
            } catch (e: OutOfMemoryError) {
                say("内存不够了，请换一张小一点的照片。")
            } catch (e: Throwable) {
                say("出错：${e.javaClass.simpleName} ${e.message}")
            } finally {
                runOnUiThread { busy = false }
            }
        }.start()
    }

    private fun process(s: Uri, t: Uri, all: Boolean, opts: SwapOptions): Pair<Bitmap, String> {
        say("正在加载模型…")
        val eng = engine ?: try {
            FaceEngine(this)
        } catch (e: Throwable) {
            throw UserError("模型加载失败：${e.javaClass.simpleName} ${e.message}")
        }
        engine = eng

        say("读取照片…")
        val srcBmp = ImageLoader.load(this, s, 2048)
        val tgtBmp = ImageLoader.load(this, t, 2560)

        say("检测来源照片里的脸…")
        val sf = eng.detect(srcBmp).maxByOrNull { it.area }
            ?: throw UserError("来源照片里没有检测到人脸，换一张正脸清楚的照片试试。")
        val emb = eng.embed(srcBmp, sf)

        say("检测目标照片里的脸…")
        val faces = eng.detect(tgtBmp).sortedByDescending { it.area }
        if (faces.isEmpty()) throw UserError("目标照片里没有检测到人脸。")
        val chosen = if (all) faces else faces.take(1)

        val out = tgtBmp.copy(Bitmap.Config.ARGB_8888, true)
        val notes = ArrayList<String>()
        for ((i, f) in chosen.withIndex()) {
            say("正在换第 ${i + 1} / ${chosen.size} 张脸…")
            if (abs(f.yaw()) > 0.4f || abs(f.pitch() - 0.5f) > 0.2f) {
                notes.add("第 ${i + 1} 张脸转头或低头角度偏大，效果可能不好。")
            }
            eng.swap(tgtBmp, out, f, emb, opts)
        }
        return Pair(out, notes.joinToString("\n"))
    }

    // ------------------------------------------------------------ 视频

    override fun onResume() {
        super.onResume()
        if (VideoJob.running) startPolling()
    }

    override fun onPause() {
        handler.removeCallbacks(pollTask)
        polling = false
        super.onPause()
    }

    private fun startPolling() {
        if (!polling) {
            polling = true
            handler.post(pollTask)
        }
    }

    private fun pickVideo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(i, REQ_VIDEO)
    }

    private fun describeVideo(uri: Uri) {
        videoInfo.text = "读取视频信息…"
        Thread {
            val text = try {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, uri)
                val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "?"
                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"
                r.release()
                val name = ModelManager.displayName(contentResolver, uri)
                "$name\n时长 ${dur / 1000} 秒，画面 ${w}x${h}"
            } catch (e: Exception) {
                "无法读取这个视频：${e.message}"
            }
            runOnUiThread { videoInfo.text = text }
        }.start()
    }

    private fun startVideo() {
        if (VideoJob.running) return
        if (busy) {
            videoStatus.text = "请等当前操作完成。"
            return
        }
        val s = srcUri
        val v = videoUri
        if (s == null) {
            videoStatus.text = "请先在上面选好来源照片。"
            return
        }
        if (v == null) {
            videoStatus.text = "请先选择目标视频。"
            return
        }
        if (!ModelManager.ready(this)) {
            videoStatus.text = "模型还没准备好，请先下载或导入模型。"
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        val idx = (fpsGroup.checkedRadioButtonId - 100).coerceIn(0, fpsValues.size - 1)
        val intent = Intent(this, VideoService::class.java).apply {
            putExtra("video", v.toString())
            putExtra("source", s.toString())
            putExtra("strength", strengthBar.progress / 100f)
            putExtra("color", colorBar.progress / 100f)
            putExtra("sharpen", sharpenBar.progress / 100f * 1.5f)
            putExtra("maxFps", fpsValues[idx])
        }
        VideoJob.reset("正在启动…")
        try {
            startForegroundService(intent)
        } catch (e: Exception) {
            VideoJob.running = false
            videoStatus.text = "无法启动后台处理：${e.message}"
            return
        }
        startPolling()
    }

    // ------------------------------------------------------------ 保存

    private fun save() {
        val bmp = result ?: return
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "faceswap_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceSwap")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                say("保存失败。")
                return
            }
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            say("已保存到相册（Pictures/FaceSwap）。")
        } catch (e: Exception) {
            say("保存失败：${e.message}")
        }
    }

    companion object {
        private const val REQ_SRC = 1
        private const val REQ_TGT = 2
        private const val REQ_MODEL = 3
        private const val REQ_VIDEO = 4
    }
}
