package com.example.faceswaplocal

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

class Face(
    val x1: Float, val y1: Float, val x2: Float, val y2: Float,
    val score: Float,
    val kps: FloatArray,
) {
    val area: Float get() = (x2 - x1) * (y2 - y1)

    fun yaw(): Float {
        val ex = kps[2] - kps[0]
        val ey = kps[3] - kps[1]
        val d = hypot(ex, ey)
        if (d < 1e-3f) return 0f
        val ux = ex / d
        val uy = ey / d
        val mx = (kps[0] + kps[2]) / 2
        val my = (kps[1] + kps[3]) / 2
        return ((kps[4] - mx) * ux + (kps[5] - my) * uy) / d
    }

    fun pitch(): Float {
        val ex = kps[2] - kps[0]
        val ey = kps[3] - kps[1]
        val d = hypot(ex, ey)
        if (d < 1e-3f) return 0.5f
        val vx = -ey / d
        val vy = ex / d
        val mx = (kps[0] + kps[2]) / 2
        val my = (kps[1] + kps[3]) / 2
        val mouthX = (kps[6] + kps[8]) / 2
        val mouthY = (kps[7] + kps[9]) / 2
        val dm = (mouthX - mx) * vx + (mouthY - my) * vy
        if (abs(dm) < 1e-3f) return 0.5f
        return ((kps[4] - mx) * vx + (kps[5] - my) * vy) / dm
    }
}

/**
 * 本地高速换脸引擎（稳定性加固版）：
 * 1. 自适应兼容 Float32 与 Float16 (FP16) 输入/输出模型，彻底杜绝类型不匹配或原生层崩溃
 * 2. 自适应兼容 128x128 (InSwapper) 与 256x256 (HyperSwap) 模型
 * 3. 自动解析 InSwapper 内置 emap 矩阵做身份特征投影
 * 4. 支持视频时域色彩平滑，彻底消除闪烁
 */
class FaceEngine(ctx: Context) : AutoCloseable {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val det: OrtSession
    private val rec: OrtSession
    private val swp: OrtSession
    private val swapSize: Int
    private val emap: FloatArray?

    private var smoothColorStats: FloatArray? = null

    init {
        fun open(name: String): OrtSession {
            val o = OrtSession.SessionOptions()
            val threads = max(2, min(4, Runtime.getRuntime().availableProcessors() / 2))
            o.setIntraOpNumThreads(threads)
            o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.BASIC_OPT)
            return env.createSession(ModelManager.file(ctx, name).absolutePath, o)
        }
        det = open(ModelManager.DET)
        rec = open(ModelManager.REC)
        swp = open(ModelManager.SWAP)

        val targetInputInfo = swp.inputInfo.values.firstOrNull {
            val shape = (it.info as? TensorInfo)?.shape
            shape != null && shape.size == 4
        }
        val shape = (targetInputInfo?.info as? TensorInfo)?.shape
        swapSize = if (shape != null && shape[2] > 0) shape[2].toInt() else 128

        emap = if (swapSize == 128) extractEmap(ModelManager.file(ctx, ModelManager.SWAP)) else null
    }

    fun resetTemporalState() {
        smoothColorStats = null
    }

    override fun close() {
        try { det.close() } catch (_: Throwable) {}
        try { rec.close() } catch (_: Throwable) {}
        try { swp.close() } catch (_: Throwable) {}
    }

    /** 根据模型节点的期望数据类型自动创建 FLOAT 或 FLOAT16 张量。 */
    private fun createSmartTensor(session: OrtSession, inputName: String, data: FloatArray, shape: LongArray): OnnxTensor {
        val info = session.inputInfo[inputName]?.info as? TensorInfo
        return if (info?.type == OnnxJavaType.FLOAT16) {
            val shorts = ShortArray(data.size) { floatToHalf(data[it]) }
            OnnxTensor.createTensor(env, ShortBuffer.wrap(shorts), shape, OnnxJavaType.FLOAT16)
        } else {
            OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape)
        }
    }

    /** 安全读取 FLOAT 或 FLOAT16 输出张量为 FloatArray。 */
    private fun readTensorFloats(tensor: OnnxTensor): FloatArray {
        return if (tensor.info.type == OnnxJavaType.FLOAT16) {
            val sb = tensor.shortBuffer
            val arr = FloatArray(sb.remaining())
            for (i in arr.indices) {
                arr[i] = halfToFloat(sb.get())
            }
            arr
        } else {
            val fb = tensor.floatBuffer
            val arr = FloatArray(fb.remaining())
            fb.get(arr)
            arr
        }
    }

    // ---------------------------------------------------------------- 检测

    fun detect(src: Bitmap, thresh: Float = 0.5f): List<Face> {
        val size = 640
        val scale = min(size.toFloat() / src.width, size.toFloat() / src.height)
        val nw = max(1, (src.width * scale).roundToInt())
        val nh = max(1, (src.height * scale).roundToInt())

        var s = src
        var sc = scale
        while (sc < 0.5f && s.width > 2 && s.height > 2) {
            s = Bitmap.createScaledBitmap(s, s.width / 2, s.height / 2, true)
            sc *= 2f
        }

        val boxed = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(boxed)
        canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(s, null, Rect(0, 0, nw, nh), Paint(Paint.FILTER_BITMAP_FLAG))

        val input = chw(boxed, 127.5f, 128f)
        val shape = longArrayOf(1, 3, size.toLong(), size.toLong())
        val candidates = ArrayList<Face>()
        val inName = det.inputNames.first()

        createSmartTensor(det, inName, input, shape).use { tensor ->
            det.run(mapOf(inName to tensor)).use { res ->
                val outs = ArrayList<FloatArray>()
                for (i in 0 until res.size()) {
                    outs.add(readTensorFloats(res.get(i) as OnnxTensor))
                }
                if (outs.size != 9) {
                    throw IllegalStateException("人脸检测模型输出数量不对（${outs.size}）")
                }
                val strides = intArrayOf(8, 16, 32)
                for ((idx, stride) in strides.withIndex()) {
                    val scores = outs[idx]
                    val boxes = outs[idx + 3]
                    val kpsOut = outs[idx + 6]
                    val cells = size / stride
                    val n = cells * cells * 2
                    if (scores.size < n || boxes.size < n * 4 || kpsOut.size < n * 10) continue
                    for (i in 0 until n) {
                        val score = scores[i]
                        if (score < thresh) continue
                        val loc = i / 2
                        val cx = (loc % cells) * stride.toFloat()
                        val cy = (loc / cells) * stride.toFloat()
                        val bx1 = (cx - boxes[i * 4] * stride) / scale
                        val by1 = (cy - boxes[i * 4 + 1] * stride) / scale
                        val bx2 = (cx + boxes[i * 4 + 2] * stride) / scale
                        val by2 = (cy + boxes[i * 4 + 3] * stride) / scale
                        val k = FloatArray(10)
                        for (j in 0 until 5) {
                            k[j * 2] = (cx + kpsOut[i * 10 + j * 2] * stride) / scale
                            k[j * 2 + 1] = (cy + kpsOut[i * 10 + j * 2 + 1] * stride) / scale
                        }
                        candidates.add(Face(bx1, by1, bx2, by2, score, k))
                    }
                }
            }
        }
        boxed.recycle()
        return nms(candidates, 0.4f)
    }

    private fun nms(list: List<Face>, iouThresh: Float): List<Face> {
        val keep = ArrayList<Face>()
        for (f in list.sortedByDescending { it.score }) {
            if (keep.none { iou(it, f) > iouThresh }) keep.add(f)
        }
        return keep
    }

    private fun iou(a: Face, b: Face): Float {
        val ix = max(0f, min(a.x2, b.x2) - max(a.x1, b.x1))
        val iy = max(0f, min(a.y2, b.y2) - max(a.y1, b.y1))
        val inter = ix * iy
        val union = a.area + b.area - inter
        return if (union <= 0f) 0f else inter / union
    }

    // ---------------------------------------------------------------- 身份特征

    fun embed(bmp: Bitmap, face: Face): FloatArray {
        val (crop, _) = align(bmp, face.kps, ARC112, 112)
        val input = chw(crop, 127.5f, 127.5f)
        crop.recycle()
        val shape = longArrayOf(1, 3, 112, 112)
        val inName = rec.inputNames.first()
        val raw: FloatArray = createSmartTensor(rec, inName, input, shape).use { tensor ->
            rec.run(mapOf(inName to tensor)).use { res ->
                readTensorFloats(res.get(0) as OnnxTensor)
            }
        }
        var norm = 0f
        for (v in raw) norm += v * v
        norm = sqrt(norm)
        if (norm > 1e-6f) for (i in raw.indices) raw[i] /= norm

        val mat = emap ?: return raw
        if (raw.size != 512) return raw
        val latent = FloatArray(512)
        for (j in 0 until 512) {
            var sum = 0f
            for (i in 0 until 512) {
                sum += raw[i] * mat[i * 512 + j]
            }
            latent[j] = sum
        }
        var lNorm = 0f
        for (v in latent) lNorm += v * v
        lNorm = sqrt(lNorm)
        if (lNorm > 1e-6f) for (i in latent.indices) latent[i] /= lNorm
        return latent
    }

    // ---------------------------------------------------------------- 换脸

    fun swap(
        cropFrom: Bitmap,
        dst: Bitmap,
        face: Face,
        embedding: FloatArray,
        opts: SwapOptions = SwapOptions(),
        isVideo: Boolean = false
    ) {
        val sz = swapSize
        val (crop, m) = align(cropFrom, face.kps, ARC128, sz)
        val isInswapper = (sz == 128)
        val targetInput = if (isInswapper) chw(crop, 0f, 255f) else chw(crop, 127.5f, 127.5f)

        val names = swp.inputNames.toList()
        val sourceName = names.firstOrNull { it.contains("source", true) } ?: names[0]
        val targetName = names.firstOrNull { it.contains("target", true) } ?: names[1]

        val srcTensor = createSmartTensor(swp, sourceName, embedding, longArrayOf(1, embedding.size.toLong()))
        val tgtTensor = createSmartTensor(swp, targetName, targetInput, longArrayOf(1, 3, sz.toLong(), sz.toLong()))
        val hw = sz * sz
        val out: FloatArray
        try {
            swp.run(mapOf(sourceName to srcTensor, targetName to tgtTensor)).use { res ->
                out = readTensorFloats(res.get(0) as OnnxTensor)
            }
        } finally {
            srcTensor.close()
            tgtTensor.close()
        }

        if (out.size < 3 * hw) {
            crop.recycle()
            throw IllegalStateException("换脸模型输出尺寸不对（${out.size}）")
        }

        val r = FloatArray(hw)
        val g = FloatArray(hw)
        val b = FloatArray(hw)
        if (isInswapper) {
            for (i in 0 until hw) {
                r[i] = out[i].coerceIn(0f, 1f) * 255f
                g[i] = out[hw + i].coerceIn(0f, 1f) * 255f
                b[i] = out[2 * hw + i].coerceIn(0f, 1f) * 255f
            }
        } else {
            for (i in 0 until hw) {
                r[i] = (out[i].coerceIn(-1f, 1f) + 1f) * 127.5f
                g[i] = (out[hw + i].coerceIn(-1f, 1f) + 1f) * 127.5f
                b[i] = (out[2 * hw + i].coerceIn(-1f, 1f) + 1f) * 127.5f
            }
        }

        val mask = if (sz == 128) MASK128 else MASK256
        val faceIdx = if (sz == 128) FACE_IDX128 else FACE_IDX256

        if (opts.colorMatch > 0f) matchColor(r, g, b, crop, opts.colorMatch, sz, faceIdx, isVideo)
        crop.recycle()
        if (opts.sharpen > 0f) sharpen(r, g, b, opts.sharpen, sz)

        val px = IntArray(hw)
        for (i in 0 until hw) {
            val a = (mask[i] * opts.strength * 255f).roundToInt().coerceIn(0, 255)
            val ri = r[i].roundToInt().coerceIn(0, 255)
            val gi = g[i].roundToInt().coerceIn(0, 255)
            val bi = b[i].roundToInt().coerceIn(0, 255)
            px[i] = (a shl 24) or (ri shl 16) or (gi shl 8) or bi
        }
        val layer = Bitmap.createBitmap(px, sz, sz, Bitmap.Config.ARGB_8888)

        val inv = Matrix()
        if (!m.invert(inv)) {
            layer.recycle()
            return
        }
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        Canvas(dst).drawBitmap(layer, inv, paint)
        layer.recycle()
    }

    // ---------------------------------------------------------------- 工具

    private fun align(src: Bitmap, kps: FloatArray, tpl: FloatArray, size: Int): Pair<Bitmap, Matrix> {
        val m = fit(kps, tpl, size)
        val vals = FloatArray(9)
        m.getValues(vals)
        var scale = hypot(vals[Matrix.MSCALE_X], vals[Matrix.MSKEW_Y])

        var s = src
        val mm = Matrix(m)
        while (scale < 0.5f && s.width > 2 && s.height > 2) {
            s = Bitmap.createScaledBitmap(s, s.width / 2, s.height / 2, true)
            mm.preScale(2f, 2f)
            scale *= 2f
        }

        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.BLACK)
        c.drawBitmap(s, mm, Paint(Paint.FILTER_BITMAP_FLAG))
        return Pair(out, m)
    }

    private fun fit(kps: FloatArray, tpl: FloatArray, size: Int): Matrix {
        val n = 5
        var sx = 0f; var sy = 0f; var dx = 0f; var dy = 0f
        for (i in 0 until n) {
            sx += kps[2 * i]; sy += kps[2 * i + 1]
            dx += tpl[2 * i] * size; dy += tpl[2 * i + 1] * size
        }
        sx /= n; sy /= n; dx /= n; dy /= n
        var num1 = 0f; var num2 = 0f; var den = 0f
        for (i in 0 until n) {
            val xs = kps[2 * i] - sx; val ys = kps[2 * i + 1] - sy
            val xd = tpl[2 * i] * size - dx; val yd = tpl[2 * i + 1] * size - dy
            num1 += xs * xd + ys * yd
            num2 += xs * yd - ys * xd
            den += xs * xs + ys * ys
        }
        if (den < 1e-6f) den = 1e-6f
        val a = num1 / den
        val b = num2 / den
        val tx = dx - (a * sx - b * sy)
        val ty = dy - (b * sx + a * sy)
        return Matrix().apply { setValues(floatArrayOf(a, -b, tx, b, a, ty, 0f, 0f, 1f)) }
    }

    private fun chw(bmp: Bitmap, mean: Float, std: Float): FloatArray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val hw = w * h
        val out = FloatArray(3 * hw)
        for (i in 0 until hw) {
            val p = px[i]
            out[i] = (((p shr 16) and 255) - mean) / std
            out[hw + i] = (((p shr 8) and 255) - mean) / std
            out[2 * hw + i] = ((p and 255) - mean) / std
        }
        return out
    }

    private fun matchColor(
        r: FloatArray, g: FloatArray, b: FloatArray,
        target: Bitmap, k: Float, sz: Int, faceIdx: IntArray, isVideo: Boolean
    ) {
        val hw = sz * sz
        val tp = IntArray(hw)
        target.getPixels(tp, 0, sz, 0, 0, sz, sz)
        val sY = FloatArray(hw); val sCb = FloatArray(hw); val sCr = FloatArray(hw)
        val tY = FloatArray(hw); val tCb = FloatArray(hw); val tCr = FloatArray(hw)
        for (i in 0 until hw) {
            val y = 0.299f * r[i] + 0.587f * g[i] + 0.114f * b[i]
            sY[i] = y; sCb[i] = b[i] - y; sCr[i] = r[i] - y
            val p = tp[i]
            val pr = ((p shr 16) and 255).toFloat()
            val pg = ((p shr 8) and 255).toFloat()
            val pb = (p and 255).toFloat()
            val py = 0.299f * pr + 0.587f * pg + 0.114f * pb
            tY[i] = py; tCb[i] = pb - py; tCr[i] = pr - py
        }
        val (msY, _) = meanStd(sY, faceIdx)
        var (mtY, _) = meanStd(tY, faceIdx)
        val (msCb, ssCb) = meanStd(sCb, faceIdx)
        var (mtCb, stCb) = meanStd(tCb, faceIdx)
        val (msCr, ssCr) = meanStd(sCr, faceIdx)
        var (mtCr, stCr) = meanStd(tCr, faceIdx)

        if (isVideo) {
            val prev = smoothColorStats
            if (prev == null) {
                smoothColorStats = floatArrayOf(mtY, mtCb, stCb, mtCr, stCr)
            } else {
                val alpha = 0.85f
                mtY = prev[0] * alpha + mtY * (1 - alpha)
                mtCb = prev[1] * alpha + mtCb * (1 - alpha)
                stCb = prev[2] * alpha + stCb * (1 - alpha)
                mtCr = prev[3] * alpha + mtCr * (1 - alpha)
                stCr = prev[4] * alpha + stCr * (1 - alpha)
                prev[0] = mtY; prev[1] = mtCb; prev[2] = stCb; prev[3] = mtCr; prev[4] = stCr
            }
        }

        val ratioCb = (stCb / max(ssCb, 1e-3f)).coerceIn(0.65f, 1.5f)
        val ratioCr = (stCr / max(ssCr, 1e-3f)).coerceIn(0.65f, 1.5f)
        for (i in 0 until hw) {
            val y2 = sY[i] + k * (mtY - msY)
            val cb2 = sCb[i] + k * ((sCb[i] - msCb) * ratioCb + mtCb - sCb[i])
            val cr2 = sCr[i] + k * ((sCr[i] - msCr) * ratioCr + mtCr - sCr[i])
            val nb = y2 + cb2
            val nr = y2 + cr2
            val ng = (y2 - 0.299f * nr - 0.114f * nb) / 0.587f
            r[i] = nr.coerceIn(0f, 255f)
            g[i] = ng.coerceIn(0f, 255f)
            b[i] = nb.coerceIn(0f, 255f)
        }
    }

    private fun meanStd(a: FloatArray, faceIdx: IntArray): Pair<Float, Float> {
        var s = 0.0
        for (i in faceIdx) s += a[i]
        val m = (s / faceIdx.size).toFloat()
        var v = 0.0
        for (i in faceIdx) {
            val d = a[i] - m
            v += d * d
        }
        return Pair(m, sqrt((v / faceIdx.size).toFloat()))
    }

    private fun sharpen(r: FloatArray, g: FloatArray, b: FloatArray, amount: Float, sz: Int) {
        val last = sz - 1
        for (ch in arrayOf(r, g, b)) {
            val src = ch.copyOf()
            for (y in 1 until last) {
                val row = y * sz
                val up = (y - 1) * sz
                val dn = (y + 1) * sz
                for (x in 1 until last) {
                    val i = row + x
                    val avg = (src[up + x] + src[dn + x] + src[i - 1] + src[i + 1]) * 0.25f
                    ch[i] = (src[i] + amount * (src[i] - avg)).coerceIn(0f, 255f)
                }
            }
        }
    }

    private fun extractEmap(onnxFile: File): FloatArray? {
        return try {
            val bytes = 512 * 512 * 4
            if (onnxFile.length() < bytes + 1024) return null
            RandomAccessFile(onnxFile, "r").use { raf ->
                raf.seek(onnxFile.length() - bytes)
                val buf = ByteArray(bytes)
                raf.readFully(buf)
                val fb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
                val arr = FloatArray(512 * 512)
                fb.get(arr)
                var valid = true
                for (k in 0 until 100) {
                    val v = arr[k * 2000]
                    if (v.isNaN() || v.isInfinite() || abs(v) > 20f) {
                        valid = false
                        break
                    }
                }
                if (valid) arr else null
            }
        } catch (_: Exception) {
            null
        }
    }

    // IEEE 754 float32 <-> float16 位转换
    private fun floatToHalf(f: Float): Short {
        val bits = java.lang.Float.floatToIntBits(f)
        val sign = (bits ushr 16) and 0x8000
        var valBits = (bits and 0x7fffffff) + 0x1000
        if (valBits >= 0x47800000) {
            return if ((bits and 0x7fffffff) >= 0x47800000) {
                if (valBits < 0x7f800000) (sign or 0x7c00).toShort()
                else (sign or 0x7c00 or ((bits and 0x007fffff) ushr 13)).toShort()
            } else (sign or 0x7bff).toShort()
        }
        if (valBits >= 0x38800000) return (sign or ((valBits - 0x38000000) ushr 13)).toShort()
        if (valBits < 0x33000000) return sign.toShort()
        valBits = (bits and 0x7fffffff) ushr 23
        return (sign or (((bits and 0x7fffff) or 0x800000) + (0x800000 ushr (valBits - 102)) ushr (126 - valBits))).toShort()
    }

    private fun halfToFloat(h: Short): Float {
        val bits = h.toInt() and 0xFFFF
        val sign = (bits and 0x8000) shl 16
        val exp = (bits ushr 10) and 0x1F
        val mant = bits and 0x03FF
        if (exp == 0) {
            if (mant == 0) return java.lang.Float.intBitsToFloat(sign)
            var e = -1
            var m = mant
            do { e++; m = m shl 1 } while ((m and 0x0400) == 0)
            return java.lang.Float.intBitsToFloat(sign or ((127 - 15 - e) shl 23) or ((m and 0x03FF) shl 13))
        }
        if (exp == 31) return java.lang.Float.intBitsToFloat(sign or 0x7F800000 or (mant shl 13))
        return java.lang.Float.intBitsToFloat(sign or ((exp + 112) shl 23) or (mant shl 13))
    }

    companion object {
        private val ARC112 = floatArrayOf(
            0.34191607f, 0.46157411f,
            0.65653393f, 0.45983393f,
            0.50022500f, 0.64050536f,
            0.37097589f, 0.82469196f,
            0.63151696f, 0.82325089f,
        )
        private val ARC128 = floatArrayOf(
            0.36167656f, 0.40387734f,
            0.63696719f, 0.40235469f,
            0.50019687f, 0.56044219f,
            0.38710391f, 0.72160547f,
            0.61507734f, 0.72034453f,
        )

        private fun buildFaceIdx(sz: Int): IntArray {
            val scale = sz / 256f
            val list = ArrayList<Int>()
            for (y in 0 until sz) {
                for (x in 0 until sz) {
                    val dx = (x - 128f * scale) / (70f * scale)
                    val dy = (y - 143f * scale) / (84f * scale)
                    if (dx * dx + dy * dy <= 1f) list.add(y * sz + x)
                }
            }
            return list.toIntArray()
        }

        private fun buildMask(sz: Int): FloatArray {
            val edge = 4f * (sz / 128f)
            val feather = 18f * (sz / 128f)
            return FloatArray(sz * sz).also {
                for (y in 0 until sz) {
                    for (x in 0 until sz) {
                        val d = min(min(x, sz - 1 - x), min(y, sz - 1 - y)).toFloat()
                        val t = ((d - edge) / feather).coerceIn(0f, 1f)
                        it[y * sz + x] = t * t * (3f - 2f * t)
                    }
                }
            }
        }

        private val FACE_IDX128 = buildFaceIdx(128)
        private val FACE_IDX256 = buildFaceIdx(256)
        private val MASK128 = buildMask(128)
        private val MASK256 = buildMask(256)
    }
}
