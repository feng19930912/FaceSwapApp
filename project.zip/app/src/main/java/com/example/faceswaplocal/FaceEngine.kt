package com.example.faceswaplocal

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** 一张检测到的人脸。kps 依次为：左眼、右眼、鼻尖、左嘴角、右嘴角（x,y 交替）。 */
class Face(
    val x1: Float, val y1: Float, val x2: Float, val y2: Float,
    val score: Float,
    val kps: FloatArray,
) {
    val area: Float get() = (x2 - x1) * (y2 - y1)

    /** 左右转头程度的粗略估计：0 约等于正脸，绝对值越大转得越多。阈值是经验值，不精确。 */
    fun yaw(): Float {
        val ex = kps[2] - kps[0]
        val ey = kps[3] - kps[1]
        val d = hypot(ex, ey)
        if (d < 1e-3f) return 0f
        val ux = ex / d
        val uy = ey / d
        val mx = (kps[0] + kps[2]) / 2
        val my = (kps[1] + kps[3]) / 2
        return ((kps[4] - mx) * ux + (kps[5] - my) * uy) / d
    }

    /** 抬头低头的粗略估计：正脸约 0.5，偏离越多说明俯仰越大。阈值是经验值，不精确。 */
    fun pitch(): Float {
        val ex = kps[2] - kps[0]
        val ey = kps[3] - kps[1]
        val d = hypot(ex, ey)
        if (d < 1e-3f) return 0.5f
        val vx = -ey / d
        val vy = ex / d
        val mx = (kps[0] + kps[2]) / 2
        val my = (kps[1] + kps[3]) / 2
        val mouthX = (kps[6] + kps[8]) / 2
        val mouthY = (kps[7] + kps[9]) / 2
        val dm = (mouthX - mx) * vx + (mouthY - my) * vy
        if (abs(dm) < 1e-3f) return 0.5f
        return ((kps[4] - mx) * vx + (kps[5] - my) * vy) / dm
    }
}

/**
 * 本地换脸流程：SCRFD 检测 → ArcFace 提取身份特征 → HyperSwap 生成 → 羽化后贴回原图。
 * 全部用 ONNX Runtime 在手机 CPU 上运行。
 */
class FaceEngine(ctx: Context) : AutoCloseable {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val det: OrtSession
    private val rec: OrtSession
    private val swp: OrtSession

    init {
        fun open(name: String): OrtSession {
            val o = OrtSession.SessionOptions()
            o.setIntraOpNumThreads(4)
            o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            return env.createSession(ModelManager.file(ctx, name).absolutePath, o)
        }
        det = open(ModelManager.DET)
        rec = open(ModelManager.REC)
        swp = open(ModelManager.SWAP)
    }

    override fun close() {
        det.close()
        rec.close()
        swp.close()
    }

    // ---------------------------------------------------------------- 检测

    fun detect(src: Bitmap, thresh: Float = 0.5f): List<Face> {
        val size = 640
        val scale = min(size.toFloat() / src.width, size.toFloat() / src.height)
        val nw = max(1, (src.width * scale).roundToInt())
        val nh = max(1, (src.height * scale).roundToInt())

        // 大图先一半一半地缩小，避免直接缩小时出现锯齿
        var s = src
        var sc = scale
        while (sc < 0.5f && s.width > 2 && s.height > 2) {
            s = Bitmap.createScaledBitmap(s, s.width / 2, s.height / 2, true)
            sc *= 2f
        }

        val boxed = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(boxed)
        canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(s, null, Rect(0, 0, nw, nh), Paint(Paint.FILTER_BITMAP_FLAG))

        val input = chw(boxed, 127.5f, 128f)
        val shape = longArrayOf(1, 3, size.toLong(), size.toLong())
        val candidates = ArrayList<Face>()

        OnnxTensor.createTensor(env, FloatBuffer.wrap(input), shape).use { tensor ->
            det.run(mapOf(det.inputNames.first() to tensor)).use { res ->
                val outs = ArrayList<FloatArray>()
                for (i in 0 until res.size()) {
                    val fb = (res.get(i) as OnnxTensor).floatBuffer
                    val a = FloatArray(fb.remaining())
                    fb.get(a)
                    outs.add(a)
                }
                if (outs.size != 9) {
                    throw IllegalStateException("人脸检测模型输出数量不对（${outs.size}），应使用 det_10g.onnx")
                }
                val strides = intArrayOf(8, 16, 32)
                for ((idx, stride) in strides.withIndex()) {
                    val scores = outs[idx]
                    val boxes = outs[idx + 3]
                    val kpsOut = outs[idx + 6]
                    val cells = size / stride
                    val n = cells * cells * 2
                    if (scores.size != n) {
                        throw IllegalStateException("人脸检测模型输出形状不对，应使用 det_10g.onnx")
                    }
                    for (i in 0 until n) {
                        val score = scores[i]
                        if (score < thresh) continue
                        val loc = i / 2
                        val cx = (loc % cells) * stride.toFloat()
                        val cy = (loc / cells) * stride.toFloat()
                        val bx1 = (cx - boxes[i * 4] * stride) / scale
                        val by1 = (cy - boxes[i * 4 + 1] * stride) / scale
                        val bx2 = (cx + boxes[i * 4 + 2] * stride) / scale
                        val by2 = (cy + boxes[i * 4 + 3] * stride) / scale
                        val k = FloatArray(10)
                        for (j in 0 until 5) {
                            k[j * 2] = (cx + kpsOut[i * 10 + j * 2] * stride) / scale
                            k[j * 2 + 1] = (cy + kpsOut[i * 10 + j * 2 + 1] * stride) / scale
                        }
                        candidates.add(Face(bx1, by1, bx2, by2, score, k))
                    }
                }
            }
        }
        boxed.recycle()
        if (s !== src) s.recycle()
        return nms(candidates, 0.4f)
    }

    private fun nms(list: List<Face>, iouThresh: Float): List<Face> {
        val keep = ArrayList<Face>()
        for (f in list.sortedByDescending { it.score }) {
            if (keep.none { iou(it, f) > iouThresh }) keep.add(f)
        }
        return keep
    }

    private fun iou(a: Face, b: Face): Float {
        val ix = max(0f, min(a.x2, b.x2) - max(a.x1, b.x1))
        val iy = max(0f, min(a.y2, b.y2) - max(a.y1, b.y1))
        val inter = ix * iy
        val union = a.area + b.area - inter
        return if (union <= 0f) 0f else inter / union
    }

    // ---------------------------------------------------------------- 身份特征

    /** 提取并归一化 512 维身份特征。 */
    fun embed(bmp: Bitmap, face: Face): FloatArray {
        val (crop, _) = align(bmp, face.kps, ARC112, 112)
        val input = chw(crop, 127.5f, 127.5f)
        crop.recycle()
        val shape = longArrayOf(1, 3, 112, 112)
        val e: FloatArray = OnnxTensor.createTensor(env, FloatBuffer.wrap(input), shape).use { tensor ->
            rec.run(mapOf(rec.inputNames.first() to tensor)).use { res ->
                val fb = (res.get(0) as OnnxTensor).floatBuffer
                val arr = FloatArray(fb.remaining())
                fb.get(arr)
                arr
            }
        }
        var norm = 0f
        for (v in e) norm += v * v
        norm = sqrt(norm)
        if (norm > 1e-6f) for (i in e.indices) e[i] = e[i] / norm
        return e
    }

    // ---------------------------------------------------------------- 换脸

    /**
     * 从 cropFrom 里按人脸位置裁出 256x256，用 HyperSwap 生成换脸后的脸，
     * 羽化边缘后贴到 dst（必须是可修改的位图）上。
     */
    fun swap(cropFrom: Bitmap, dst: Bitmap, face: Face, embedding: FloatArray) {
        val (crop, m) = align(cropFrom, face.kps, ARC128, 256)
        val targetInput = chw(crop, 127.5f, 127.5f)
        crop.recycle()

        val names = swp.inputNames.toList()
        val sourceName = names.firstOrNull { it.contains("source", true) } ?: names[0]
        val targetName = names.firstOrNull { it.contains("target", true) } ?: names[1]

        val srcTensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(embedding), longArrayOf(1, embedding.size.toLong()))
        val tgtTensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(targetInput), longArrayOf(1, 3, 256, 256))
        val out = FloatArray(3 * 256 * 256)
        try {
            swp.run(mapOf(sourceName to srcTensor, targetName to tgtTensor)).use { res ->
                val fb = (res.get(0) as OnnxTensor).floatBuffer
                if (fb.remaining() < out.size) {
                    throw IllegalStateException("换脸模型输出尺寸不对，应使用 hyperswap_1b_256.onnx")
                }
                fb.get(out, 0, out.size)
            }
        } finally {
            srcTensor.close()
            tgtTensor.close()
        }

        val hw = 256 * 256
        val px = IntArray(hw)
        for (i in 0 until hw) {
            val r = toByte(out[i])
            val g = toByte(out[hw + i])
            val b = toByte(out[2 * hw + i])
            val a = (MASK[i] * 255f).roundToInt().coerceIn(0, 255)
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        val layer = Bitmap.createBitmap(px, 256, 256, Bitmap.Config.ARGB_8888)

        val inv = Matrix()
        if (!m.invert(inv)) return
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        Canvas(dst).drawBitmap(layer, inv, paint)
        layer.recycle()
    }

    // ---------------------------------------------------------------- 工具

    /** 用五个关键点和模板求相似变换（旋转+缩放+平移），再裁出 size x size 的人脸。 */
    private fun align(src: Bitmap, kps: FloatArray, tpl: FloatArray, size: Int): Pair<Bitmap, Matrix> {
        val m = fit(kps, tpl, size)
        val vals = FloatArray(9)
        m.getValues(vals)
        var scale = hypot(vals[Matrix.MSCALE_X], vals[Matrix.MSKEW_Y])

        var s = src
        val mm = Matrix(m)
        while (scale < 0.5f && s.width > 2 && s.height > 2) {
            s = Bitmap.createScaledBitmap(s, s.width / 2, s.height / 2, true)
            mm.preScale(2f, 2f)
            scale *= 2f
        }

        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.BLACK)
        c.drawBitmap(s, mm, Paint(Paint.FILTER_BITMAP_FLAG))
        return Pair(out, m)
    }

    private fun fit(kps: FloatArray, tpl: FloatArray, size: Int): Matrix {
        val n = 5
        var sx = 0f
        var sy = 0f
        var dx = 0f
        var dy = 0f
        for (i in 0 until n) {
            sx += kps[2 * i]
            sy += kps[2 * i + 1]
            dx += tpl[2 * i] * size
            dy += tpl[2 * i + 1] * size
        }
        sx /= n; sy /= n; dx /= n; dy /= n
        var num1 = 0f
        var num2 = 0f
        var den = 0f
        for (i in 0 until n) {
            val xs = kps[2 * i] - sx
            val ys = kps[2 * i + 1] - sy
            val xd = tpl[2 * i] * size - dx
            val yd = tpl[2 * i + 1] * size - dy
            num1 += xs * xd + ys * yd
            num2 += xs * yd - ys * xd
            den += xs * xs + ys * ys
        }
        if (den < 1e-6f) den = 1e-6f
        val a = num1 / den
        val b = num2 / den
        val tx = dx - (a * sx - b * sy)
        val ty = dy - (b * sx + a * sy)
        val m = Matrix()
        m.setValues(floatArrayOf(a, -b, tx, b, a, ty, 0f, 0f, 1f))
        return m
    }

    /** 位图转 NCHW 浮点数组，RGB 顺序，(像素 - mean) / std。 */
    private fun chw(bmp: Bitmap, mean: Float, std: Float): FloatArray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val hw = w * h
        val out = FloatArray(3 * hw)
        for (i in 0 until hw) {
            val p = px[i]
            out[i] = (((p shr 16) and 255) - mean) / std
            out[hw + i] = (((p shr 8) and 255) - mean) / std
            out[2 * hw + i] = ((p and 255) - mean) / std
        }
        return out
    }

    private fun toByte(v: Float): Int = ((v.coerceIn(-1f, 1f) + 1f) * 127.5f).roundToInt().coerceIn(0, 255)

    companion object {
        // 关键点模板（归一化坐标），分别用于 112 尺寸的识别和 128 模板的换脸
        private val ARC112 = floatArrayOf(
            0.34191607f, 0.46157411f,
            0.65653393f, 0.45983393f,
            0.50022500f, 0.64050536f,
            0.37097589f, 0.82469196f,
            0.63151696f, 0.82325089f,
        )
        private val ARC128 = floatArrayOf(
            0.36167656f, 0.40387734f,
            0.63696719f, 0.40235469f,
            0.50019687f, 0.56044219f,
            0.38710391f, 0.72160547f,
            0.61507734f, 0.72034453f,
        )

        /** 贴回时的羽化遮罩：中间不透明，靠近裁剪框边缘逐渐透明。 */
        private val MASK: FloatArray = FloatArray(256 * 256).also {
            for (y in 0 until 256) {
                for (x in 0 until 256) {
                    val d = min(min(x, 255 - x), min(y, 255 - y)).toFloat()
                    val t = ((d - 8f) / 30f).coerceIn(0f, 1f)
                    it[y * 256 + x] = t * t * (3f - 2f * t)
                }
            }
        }
    }
}
