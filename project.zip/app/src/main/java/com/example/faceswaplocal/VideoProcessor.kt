package com.example.faceswaplocal

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.min

/**
 * 纯原生硬件加速视频换脸处理器：
 * 1. 使用 MediaMetadataRetriever 提取视频帧（自动处理旋转角度与时间戳）
 * 2. 使用 FaceEngine 逐帧检测并替换人脸
 * 3. 使用 MediaCodec (Surface 输入模式) 硬件编码为 H.264 视频流
 * 4. 使用 MediaMuxer 同步合并原视频音轨，输出完整的 MP4 文件
 */
object VideoProcessor {

    fun processVideo(
        ctx: Context,
        engine: FaceEngine,
        srcFaceEmb: FloatArray,
        videoUri: Uri,
        outputFile: File,
        swapAllFaces: Boolean,
        targetFps: Int = 24,
        maxDimension: Int = 720,
        isCancelled: () -> Boolean,
        onProgress: (currentFrame: Int, totalFrames: Int, preview: Bitmap?) -> Unit
    ) {
        val retriever = MediaMetadataRetriever()
        var encoder: MediaCodec? = null
        var inputSurface: Surface? = null
        var muxer: MediaMuxer? = null
        val audioExtractor = MediaExtractor()

        try {
            retriever.setDataSource(ctx, videoUri)

            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (durationMs <= 0L) throw UserError("无法读取视频时长，请换一个视频文件。")

            val rawW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val rawH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0

            val orientedW = if (rotation == 90 || rotation == 270) rawH else rawW
            val orientedH = if (rotation == 90 || rotation == 270) rawW else rawH
            if (orientedW <= 0 || orientedH <= 0) throw UserError("无法获取视频分辨率。")

            // 等比例缩放并确保宽高为 16 的倍数（硬件编码器要求对齐）
            val scale = min(1f, maxDimension.toFloat() / maxOf(orientedW, orientedH))
            val outW = (((orientedW * scale).toInt() + 15) / 16) * 16
            val outH = (((orientedH * scale).toInt() + 15) / 16) * 16

            // 配置 H.264 硬件编码器
            val mime = MediaFormat.MIMETYPE_VIDEO_AVC
            val format = MediaFormat.createVideoFormat(mime, outW, outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, (outW * outH * 4).coerceIn(1_500_000, 8_000_000))
                setInteger(MediaFormat.KEY_FRAME_RATE, targetFps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            encoder = MediaCodec.createEncoderByType(mime)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = encoder.createInputSurface()
            encoder.start()

            if (outputFile.exists()) outputFile.delete()
            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            // 准备原视频音轨（如果有）
            var audioTrackIndex = -1
            var muxerAudioTrackIndex = -1
            try {
                audioExtractor.setDataSource(ctx, videoUri, null)
                for (i in 0 until audioExtractor.trackCount) {
                    val trackFormat = audioExtractor.getTrackFormat(i)
                    val trackMime = trackFormat.getString(MediaFormat.KEY_MIME) ?: ""
                    if (trackMime.startsWith("audio/")) {
                        audioTrackIndex = i
                        audioExtractor.selectTrack(i)
                        muxerAudioTrackIndex = muxer.addTrack(trackFormat)
                        break
                    }
                }
            } catch (_: Exception) {
                audioTrackIndex = -1
            }

            var muxerVideoTrackIndex = -1
            var muxerStarted = false
            val bufferInfo = MediaCodec.BufferInfo()

            fun drainEncoder(endOfStream: Boolean) {
                if (endOfStream) {
                    encoder!!.signalEndOfInputStream()
                }
                while (true) {
                    val status = encoder!!.dequeueOutputBuffer(bufferInfo, 10_000L)
                    if (status == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!endOfStream) break
                    } else if (status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (muxerStarted) throw IllegalStateException("输出格式重复变更")
                        muxerVideoTrackIndex = muxer!!.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    } else if (status >= 0) {
                        val encodedData = encoder.getOutputBuffer(status)
                            ?: throw IllegalStateException("编码器输出缓冲为空")
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }
                        if (bufferInfo.size > 0 && muxerStarted) {
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            muxer!!.writeSampleData(muxerVideoTrackIndex, encodedData, bufferInfo)
                        }
                        encoder.releaseOutputBuffer(status, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            break
                        }
                    }
                }
            }

            val intervalUs = 1_000_000L / targetFps
            val totalFrames = ((durationMs * targetFps) / 1000L).toInt().coerceAtLeast(1)
            var frameIndex = 0
            var timeUs = 0L

            while (timeUs < durationMs * 1000L) {
                if (isCancelled()) throw UserError("已取消视频处理。")

                val rawFrame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    retriever.getScaledFrameAtTime(
                        timeUs,
                        MediaMetadataRetriever.OPTION_CLOSEST,
                        outW,
                        outH
                    )
                } else {
                    retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                }

                if (rawFrame != null) {
                    val scaledFrame = if (rawFrame.width != outW || rawFrame.height != outH) {
                        Bitmap.createScaledBitmap(rawFrame, outW, outH, true).also { rawFrame.recycle() }
                    } else {
                        rawFrame
                    }
                    val workingBmp = scaledFrame.copy(Bitmap.Config.ARGB_8888, true)
                    scaledFrame.recycle()

                    // 执行换脸
                    val faces = engine.detect(workingBmp)
                    if (faces.isNotEmpty()) {
                        val chosen = if (swapAllFaces) faces else faces.sortedByDescending { abs(it.area) }.take(1)
                        for (f in chosen) {
                            engine.swap(workingBmp, workingBmp, f, srcFaceEmb)
                        }
                    }

                    // 绘制到编码器 Surface（设置精确时间戳）
                    val canvas = inputSurface.lockCanvas(null)
                    try {
                        canvas.drawBitmap(workingBmp, 0f, 0f, null)
                    } finally {
                        inputSurface.unlockCanvasAndPost(canvas)
                    }

                    drainEncoder(false)

                    frameIndex++
                    // 每处理 3 帧更新一次界面缩略图，兼顾流畅度与内存安全
                    val previewCopy = if (frameIndex % 3 == 1 || frameIndex == totalFrames) {
                        workingBmp.copy(Bitmap.Config.ARGB_8888, false)
                    } else {
                        null
                    }
                    workingBmp.recycle()
                    onProgress(frameIndex, totalFrames, previewCopy)
                }

                timeUs += intervalUs
            }

            drainEncoder(true)

            // 写入原视频音频轨道
            if (muxerStarted && audioTrackIndex >= 0 && muxerAudioTrackIndex >= 0) {
                val audioBuf = ByteBuffer.allocate(512 * 1024)
                val audioInfo = MediaCodec.BufferInfo()
                while (true) {
                    val sampleSize = audioExtractor.readSampleData(audioBuf, 0)
                    if (sampleSize < 0) break
                    val sampleTime = audioExtractor.sampleTime
                    if (sampleTime > durationMs * 1000L) break
                    audioInfo.offset = 0
                    audioInfo.size = sampleSize
                    audioInfo.presentationTimeUs = sampleTime
                    audioInfo.flags = audioExtractor.sampleFlags
                    muxer.writeSampleData(muxerAudioTrackIndex, audioBuf, audioInfo)
                    audioExtractor.advance()
                }
            }

            if (muxerStarted) {
                muxer.stop()
            }
        } finally {
            try { retriever.release() } catch (_: Exception) {}
            try { audioExtractor.release() } catch (_: Exception) {}
            try { encoder?.stop(); encoder?.release() } catch (_: Exception) {}
            try { inputSurface?.release() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }
}
