package com.example.faceswaplocal

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Paint
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 视频换脸：解码每一帧 → 检测并换脸 → 重新编码为 H.264，原声直接复制。
 * 只处理一张脸（默认最大的那张，之后跟踪同一张）。
 */
class VideoProcessor(private val ctx: Context, private val engine: FaceEngine) {

    class Params(
        val video: Uri,
        val embedding: FloatArray,
        val opts: SwapOptions,
        val maxFps: Int,
        val maxSide: Int,
    )

    @Volatile
    var cancelled = false

    var audioSkipped = false
        private set

    // 视频颜色解码参数
    private var use709 = true
    private var fullRange = false

    // 封装器状态
    private var muxer: MediaMuxer? = null
    private var muxStarted = false
    private var muxStopped = false
    private var vOutTrack = -1
    private var aOutTrack = -1
    private var audioFormat: MediaFormat? = null

    // 人脸跟踪与防抖状态
    private var prevFace: Face? = null
    private var frameCounter = 0
    private var missedFrames = 0

    /** 返回 true 表示完成，false 表示被取消。 */
    fun run(p: Params, outFile: File, onProgress: (Int, Long, Long) -> Unit): Boolean {
        val vEx = MediaExtractor()
        val aEx = MediaExtractor()
        var dec: MediaCodec? = null
        var enc: MediaCodec? = null
        prevFace = null
        frameCounter = 0
        missedFrames = 0
        engine.resetTemporalState()
        try {
            vEx.setDataSource(ctx, p.video, null)
            aEx.setDataSource(ctx, p.video, null)

            var vTrack = -1
            var aTrack = -1
            for (i in 0 until vEx.trackCount) {
                val mime = vEx.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (vTrack < 0 && mime.startsWith("video/")) vTrack = i
                if (aTrack < 0 && mime.startsWith("audio/")) aTrack = i
            }
            if (vTrack < 0) throw UserError("这个文件里没有视频画面。")

            val vFormat = vEx.getTrackFormat(vTrack)
            vEx.selectTrack(vTrack)
            val mime = vFormat.getString(MediaFormat.KEY_MIME) ?: throw UserError("无法识别视频格式。")
            val srcW = vFormat.getInteger(MediaFormat.KEY_WIDTH)
            val srcH = vFormat.getInteger(MediaFormat.KEY_HEIGHT)
            val rotation = if (vFormat.containsKey(MediaFormat.KEY_ROTATION)) vFormat.getInteger(MediaFormat.KEY_ROTATION) else 0
            val durationUs = if (vFormat.containsKey(MediaFormat.KEY_DURATION)) vFormat.getLong(MediaFormat.KEY_DURATION) else 0L
            val outFps = max(1, min(readFps(vFormat), p.maxFps))

            if (vFormat.containsKey(MediaFormat.KEY_COLOR_TRANSFER)) {
                val tr = vFormat.getInteger(MediaFormat.KEY_COLOR_TRANSFER)
                if (tr == MediaFormat.COLOR_TRANSFER_ST2084 || tr == MediaFormat.COLOR_TRANSFER_HLG) {
                    throw UserError("暂不支持 HDR 视频，请先在相册里把它转成普通视频再试。")
                }
            }
            val std = if (vFormat.containsKey(MediaFormat.KEY_COLOR_STANDARD)) vFormat.getInteger(MediaFormat.KEY_COLOR_STANDARD) else 0
            use709 = when (std) {
                MediaFormat.COLOR_STANDARD_BT709, MediaFormat.COLOR_STANDARD_BT2020 -> true
                MediaFormat.COLOR_STANDARD_BT601_PAL, MediaFormat.COLOR_STANDARD_BT601_NTSC -> false
                else -> srcH >= 720
            }
            fullRange = vFormat.containsKey(MediaFormat.KEY_COLOR_RANGE) &&
                vFormat.getInteger(MediaFormat.KEY_COLOR_RANGE) == MediaFormat.COLOR_RANGE_FULL

            // 输出尺寸：先按旋转后的方向，再限制最长边，宽高取偶数
            val rotW = if (rotation == 90 || rotation == 270) srcH else srcW
            val rotH = if (rotation == 90 || rotation == 270) srcW else srcH
            val scale = min(1f, p.maxSide.toFloat() / max(rotW, rotH))
            val outW = max(2, (rotW * scale).toInt() / 2 * 2)
            val outH = max(2, (rotH * scale).toInt() / 2 * 2)

            // 解码器
            vFormat.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible,
            )
            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(vFormat, null, null, 0)
            decoder.start()
            dec = decoder

            // 编码器
            val bitrate = (outW.toLong() * outH * outFps * 0.3).toInt().coerceIn(3_000_000, 20_000_000)
            val ef = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, outW, outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, outFps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                setInteger(
                    MediaFormat.KEY_COLOR_STANDARD,
                    if (use709) MediaFormat.COLOR_STANDARD_BT709 else MediaFormat.COLOR_STANDARD_BT601_NTSC,
                )
                setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
                setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
            }
            val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()
            enc = encoder

            val mx = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mx.setOrientationHint(0)
            muxer = mx
            audioFormat = if (aTrack >= 0) aEx.getTrackFormat(aTrack) else null

            val info = MediaCodec.BufferInfo()
            val stepUs = 1_000_000L / outFps
            var inputEos = false
            var outputEos = false
            var nextKeepUs = 0L
            var frames = 0
            var lastPts = 0L

            while (!outputEos) {
                if (cancelled) return false

                if (!inputEos) {
                    val ii = decoder.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = decoder.getInputBuffer(ii)!!
                        val n = vEx.readSampleData(buf, 0)
                        if (n < 0) {
                            decoder.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEos = true
                        } else {
                            decoder.queueInputBuffer(ii, 0, n, vEx.sampleTime, 0)
                            vEx.advance()
                        }
                    }
                }

                val oi = decoder.dequeueOutputBuffer(info, 10_000)
                if (oi >= 0) {
                    val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    val pts = info.presentationTimeUs
                    if (info.size > 0 && pts >= nextKeepUs) {
                        val img = decoder.getOutputImage(oi)
                            ?: throw UserError("这台手机的解码器不支持读取这个视频的画面。")
                        val frame = try {
                            makeFrame(img, rotation, outW, outH)
                        } finally {
                            img.close()
                        }
                        val result = swapFrame(frame, p)
                        encodeFrame(encoder, result, pts)
                        result.recycle()
                        nextKeepUs = pts + stepUs - stepUs / 4
                        lastPts = pts
                        frames++
                        onProgress(frames, pts, durationUs)
                    }
                    decoder.releaseOutputBuffer(oi, false)
                    if (eos) outputEos = true
                }
            }

            if (frames == 0) throw UserError("没有读到任何画面。")

            // 结束编码
            var idx = encoder.dequeueInputBuffer(10_000)
            while (idx < 0) {
                drainEncoder(encoder, false)
                idx = encoder.dequeueInputBuffer(10_000)
            }
            encoder.queueInputBuffer(idx, 0, 0, lastPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drainEncoder(encoder, true)

            if (!muxStarted) throw UserError("视频编码没有输出任何内容。")
            if (aTrack >= 0 && aOutTrack >= 0) {
                try {
                    copyAudio(aEx, aTrack, mx, aOutTrack)
                } catch (e: Exception) {
                    audioSkipped = true
                }
            }
            mx.stop()
            muxStopped = true
            return true
        } finally {
            try { dec?.stop() } catch (e: Exception) { }
            try { dec?.release() } catch (e: Exception) { }
            try { enc?.stop() } catch (e: Exception) { }
            try { enc?.release() } catch (e: Exception) { }
            val m = muxer
            if (m != null) {
                try { if (muxStarted && !muxStopped) m.stop() } catch (e: Exception) { }
                try { m.release() } catch (e: Exception) { }
            }
            muxer = null
            muxStarted = false
            muxStopped = false
            vOutTrack = -1
            aOutTrack = -1
            vEx.release()
            aEx.release()
        }
    }

    // ------------------------------------------------------------ 换脸与跟踪（跳帧检测 + 速度自适应防抖）

    private fun swapFrame(frame: Bitmap, p: Params): Bitmap {
        frameCounter++
        val shouldDetect = (prevFace == null) || (frameCounter % 3 == 1)

        if (!shouldDetect && prevFace != null) {
            engine.swap(frame, frame, prevFace!!, p.embedding, p.opts, isVideo = true)
            return frame
        }

        val faces = engine.detect(frame)
        if (faces.isEmpty()) {
            missedFrames++
            if (missedFrames > 3) {
                prevFace = null
            } else if (prevFace != null) {
                engine.swap(frame, frame, prevFace!!, p.embedding, p.opts, isVideo = true)
            }
            return frame
        }

        missedFrames = 0
        val face = pickAndSmooth(faces)
        engine.swap(frame, frame, face, p.embedding, p.opts, isVideo = true)
        return frame
    }

    /** 速度自适应平滑滤波：静止时强锁定不抖动，快速转头时高响应不拖影。 */
    private fun pickAndSmooth(faces: List<Face>): Face {
        val prev = prevFace
        val largest = faces.maxByOrNull { it.area }!!
        if (prev == null) {
            prevFace = largest
            return largest
        }
        val pcx = (prev.x1 + prev.x2) / 2
        val pcy = (prev.y1 + prev.y2) / 2
        val near = faces.minByOrNull { hypot((it.x1 + it.x2) / 2 - pcx, (it.y1 + it.y2) / 2 - pcy) }!!
        val d = hypot((near.x1 + near.x2) / 2 - pcx, (near.y1 + near.y2) / 2 - pcy)
        val size = max(prev.x2 - prev.x1, prev.y2 - prev.y1)
        if (d > size * 1.2f) {
            prevFace = largest
            return largest
        }

        var kpsShift = 0f
        for (i in 0 until 5) {
            kpsShift += hypot(near.kps[i * 2] - prev.kps[i * 2], near.kps[i * 2 + 1] - prev.kps[i * 2 + 1])
        }
        val normSpeed = (kpsShift / 5f) / max(size, 1f)
        val w = (0.22f + normSpeed * 3.5f).coerceIn(0.22f, 0.75f)

        val k = FloatArray(10) { prev.kps[it] * (1 - w) + near.kps[it] * w }
        val smoothed = Face(
            prev.x1 * (1 - w) + near.x1 * w,
            prev.y1 * (1 - w) + near.y1 * w,
            prev.x2 * (1 - w) + near.x2 * w,
            prev.y2 * (1 - w) + near.y2 * w,
            near.score,
            k,
        )
        prevFace = smoothed
        return smoothed
    }

    // ------------------------------------------------------------ 编码

    private fun encodeFrame(enc: MediaCodec, bmp: Bitmap, ptsUs: Long) {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        var idx = enc.dequeueInputBuffer(10_000)
        while (idx < 0) {
            drainEncoder(enc, false)
            idx = enc.dequeueInputBuffer(10_000)
        }
        val img = enc.getInputImage(idx) ?: throw UserError("这台手机的编码器不支持这种输入。")
        fillImage(img, px, w, h)
        enc.queueInputBuffer(idx, 0, w * h * 3 / 2, ptsUs, 0)
        drainEncoder(enc, false)
    }

    private fun drainEncoder(enc: MediaCodec, endOfStream: Boolean) {
        val info = MediaCodec.BufferInfo()
        val deadline = System.currentTimeMillis() + 15_000
        while (true) {
            val oi = enc.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
            if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) return
                if (System.currentTimeMillis() > deadline) throw UserError("视频编码超时。")
            } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val mx = muxer ?: return
                vOutTrack = mx.addTrack(enc.outputFormat)
                val af = audioFormat
                aOutTrack = -1
                if (af != null) {
                    try {
                        aOutTrack = mx.addTrack(af)
                    } catch (e: Exception) {
                        aOutTrack = -1
                        audioSkipped = true
                    }
                }
                mx.start()
                muxStarted = true
            } else if (oi >= 0) {
                val buf = enc.getOutputBuffer(oi)
                if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                val mx = muxer
                if (info.size > 0 && muxStarted && buf != null && mx != null) {
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    mx.writeSampleData(vOutTrack, buf, info)
                }
                enc.releaseOutputBuffer(oi, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }

    private fun copyAudio(ex: MediaExtractor, track: Int, mx: MediaMuxer, outTrack: Int) {
        ex.selectTrack(track)
        ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        val buf = ByteBuffer.allocate(1 shl 20)
        val info = MediaCodec.BufferInfo()
        while (true) {
            if (cancelled) return
            val n = ex.readSampleData(buf, 0)
            if (n < 0) break
            info.offset = 0
            info.size = n
            info.presentationTimeUs = ex.sampleTime
            info.flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
            mx.writeSampleData(outTrack, buf, info)
            ex.advance()
        }
    }

    // ------------------------------------------------------------ 颜色转换

    /** 解码得到的 YUV 画面 → 旋转、缩放后的 ARGB 位图。 */
    private fun makeFrame(img: Image, rotation: Int, outW: Int, outH: Int): Bitmap {
        if (img.format != ImageFormat.YUV_420_888) {
            throw UserError("暂不支持这种格式的视频（可能是 10bit 或 HDR），请先转成普通视频再试。")
        }
        val src = imageToBitmap(img)
        val m = frameMatrix(src.width, src.height, rotation, outW, outH)
        val frame = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        Canvas(frame).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        src.recycle()
        return frame
    }

    private fun frameMatrix(w: Int, h: Int, rot: Int, outW: Int, outH: Int): Matrix {
        val m = Matrix()
        val rw: Float
        val rh: Float
        when (rot) {
            90 -> {
                m.postRotate(90f)
                m.postTranslate(h.toFloat(), 0f)
                rw = h.toFloat(); rh = w.toFloat()
            }
            180 -> {
                m.postRotate(180f)
                m.postTranslate(w.toFloat(), h.toFloat())
                rw = w.toFloat(); rh = h.toFloat()
            }
            270 -> {
                m.postRotate(270f)
                m.postTranslate(0f, w.toFloat())
                rw = h.toFloat(); rh = w.toFloat()
            }
            else -> {
                rw = w.toFloat(); rh = h.toFloat()
            }
        }
        m.postScale(outW / rw, outH / rh)
        return m
    }

    private fun imageToBitmap(img: Image): Bitmap {
        val crop = img.cropRect
        val w = crop.width()
        val h = crop.height()
        val planes = img.planes
        val yBuf = planes[0].buffer
        val uBuf = planes[1].buffer
        val vBuf = planes[2].buffer
        val yArr = ByteArray(yBuf.remaining()).also { yBuf.get(it) }
        val uArr = ByteArray(uBuf.remaining()).also { uBuf.get(it) }
        val vArr = ByteArray(vBuf.remaining()).also { vBuf.get(it) }
        val yRs = planes[0].rowStride
        val yPs = planes[0].pixelStride
        val uRs = planes[1].rowStride
        val uPs = planes[1].pixelStride
        val vRs = planes[2].rowStride
        val vPs = planes[2].pixelStride

        val crR: Float
        val gCb: Float
        val gCr: Float
        val cbB: Float
        if (use709) {
            crR = 1.5748f; gCb = 0.1873f; gCr = 0.4681f; cbB = 1.8556f
        } else {
            crR = 1.402f; gCb = 0.3441f; gCr = 0.7141f; cbB = 1.772f
        }
        val yScale = if (fullRange) 1f else 255f / 219f
        val yOff = if (fullRange) 0f else 16f
        val cScale = if (fullRange) 1f else 255f / 224f

        val px = IntArray(w * h)
        for (j in 0 until h) {
            val yy = j + crop.top
            val yRow = yy * yRs
            val uRow = (yy shr 1) * uRs
            val vRow = (yy shr 1) * vRs
            for (i in 0 until w) {
                val xx = i + crop.left
                val yv = yArr[yRow + xx * yPs].toInt() and 255
                val uv = uArr[uRow + (xx shr 1) * uPs].toInt() and 255
                val vv = vArr[vRow + (xx shr 1) * vPs].toInt() and 255
                val yf = (yv - yOff) * yScale
                val cb = (uv - 128f) * cScale
                val cr = (vv - 128f) * cScale
                val r = yf + crR * cr
                val g = yf - gCb * cb - gCr * cr
                val b = yf + cbB * cb
                px[j * w + i] = (0xFF shl 24) or (clamp255(r) shl 16) or (clamp255(g) shl 8) or clamp255(b)
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun clamp255(v: Float): Int {
        val i = (v + 0.5f).toInt()
        return if (i < 0) 0 else if (i > 255) 255 else i
    }

    /** ARGB → 编码器要的 YUV420（有限范围），色度取 2x2 的平均。 */
    private fun fillImage(img: Image, px: IntArray, w: Int, h: Int) {
        val planes = img.planes
        val yBuf = planes[0].buffer
        val uBuf = planes[1].buffer
        val vBuf = planes[2].buffer
        val yRs = planes[0].rowStride
        val yPs = planes[0].pixelStride
        val uRs = planes[1].rowStride
        val uPs = planes[1].pixelStride
        val vRs = planes[2].rowStride
        val vPs = planes[2].pixelStride

        val kr = if (use709) 0.2126f else 0.299f
        val kb = if (use709) 0.0722f else 0.114f
        val kg = 1f - kr - kb
        val cbDiv = 2f * (1f - kb)
        val crDiv = 2f * (1f - kr)

        var j = 0
        while (j < h) {
            var i = 0
            while (i < w) {
                var cbSum = 0f
                var crSum = 0f
                for (dy in 0..1) {
                    for (dx in 0..1) {
                        val x = i + dx
                        val y = j + dy
                        val p = px[y * w + x]
                        val r = ((p shr 16) and 255).toFloat()
                        val g = ((p shr 8) and 255).toFloat()
                        val b = (p and 255).toFloat()
                        val yy = kr * r + kg * g + kb * b
                        yBuf.put(y * yRs + x * yPs, (16f + 219f / 255f * yy).roundToInt().toByte())
                        cbSum += (b - yy) / cbDiv
                        crSum += (r - yy) / crDiv
                    }
                }
                val u = (128f + 224f / 255f * (cbSum / 4f)).roundToInt().coerceIn(16, 240)
                val v = (128f + 224f / 255f * (crSum / 4f)).roundToInt().coerceIn(16, 240)
                val cx = i shr 1
                val cy = j shr 1
                uBuf.put(cy * uRs + cx * uPs, u.toByte())
                vBuf.put(cy * vRs + cx * vPs, v.toByte())
                i += 2
            }
            j += 2
        }
    }

    private fun readFps(f: MediaFormat): Int {
        if (!f.containsKey(MediaFormat.KEY_FRAME_RATE)) return 30
        return try {
            f.getInteger(MediaFormat.KEY_FRAME_RATE)
        } catch (e: Exception) {
            try {
                f.getFloat(MediaFormat.KEY_FRAME_RATE).roundToInt()
            } catch (e2: Exception) {
                30
            }
        }
    }
}
