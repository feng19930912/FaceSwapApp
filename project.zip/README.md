# FaceSwapLocal (本地换脸)

本地运行的 Android 换脸应用，使用 ONNX Runtime + InsightFace 模型。

## 构建

使用 GitHub Actions 自动构建 Debug APK：

1. 将本项目推送到 GitHub 仓库（main 或 master 分支）
2. 在 Actions 标签页手动触发或 push 后自动运行
3. 完成后在 Artifacts 中下载 `FaceSwapLocal-APK`

本地构建需要 Android SDK (API 34) + JDK 17：

```bash
./gradlew assembleDebug
```

APK 输出位置：`app/build/outputs/apk/debug/app-debug.apk`

## 使用说明

应用启动后会自动下载所需模型文件（约几百 MB），请保持网络连接。支持图片与视频换脸。
